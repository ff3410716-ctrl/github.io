"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  ReactNode,
} from "react";
import { Trade, AppSettings, MistakeStatusEntry } from "@/lib/types";

type AppDataContextValue = {
  trades: Trade[];
  settings: AppSettings | null;
  mistakeStatuses: MistakeStatusEntry[];
  loading: boolean;
  error: string | null;
  refreshTrades: () => Promise<void>;
  refreshSettings: () => Promise<void>;
  refreshMistakes: () => Promise<void>;
  createTrade: (payload: Record<string, unknown>) => Promise<Trade>;
  updateTrade: (id: number, payload: Record<string, unknown>) => Promise<Trade>;
  deleteTrade: (id: number) => Promise<void>;
  updateSettings: (payload: Partial<AppSettings>) => Promise<void>;
  setMistakeStatus: (mistake: string, status: string) => Promise<void>;
};

const AppDataContext = createContext<AppDataContextValue | null>(null);

export function AppDataProvider({ children }: { children: ReactNode }) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [mistakeStatuses, setMistakeStatuses] = useState<MistakeStatusEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshTrades = useCallback(async () => {
    const res = await fetch("/api/trades");
    const data = await res.json();
    if (res.ok) setTrades(data.trades ?? []);
  }, []);

  const refreshSettings = useCallback(async () => {
    const res = await fetch("/api/settings");
    const data = await res.json();
    if (res.ok) setSettings(data.settings ?? null);
  }, []);

  const refreshMistakes = useCallback(async () => {
    const res = await fetch("/api/mistakes");
    const data = await res.json();
    if (res.ok) setMistakeStatuses(data.statuses ?? []);
  }, []);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        await Promise.all([refreshTrades(), refreshSettings(), refreshMistakes()]);
      } catch {
        setError("Failed to load data. Please refresh the page.");
      } finally {
        setLoading(false);
      }
    })();
  }, [refreshTrades, refreshSettings, refreshMistakes]);

  const createTrade = useCallback(
    async (payload: Record<string, unknown>) => {
      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to create trade");
      await refreshTrades();
      return data.trade as Trade;
    },
    [refreshTrades]
  );

  const updateTrade = useCallback(
    async (id: number, payload: Record<string, unknown>) => {
      const res = await fetch(`/api/trades/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update trade");
      await refreshTrades();
      return data.trade as Trade;
    },
    [refreshTrades]
  );

  const deleteTrade = useCallback(
    async (id: number) => {
      const res = await fetch(`/api/trades/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete trade");
      await refreshTrades();
    },
    [refreshTrades]
  );

  const updateSettings = useCallback(
    async (payload: Partial<AppSettings>) => {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...settings, ...payload }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update settings");
      setSettings(data.settings);
    },
    [settings]
  );

  const setMistakeStatus = useCallback(
    async (mistake: string, status: string) => {
      const res = await fetch("/api/mistakes", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mistake, status }),
      });
      if (!res.ok) throw new Error("Failed to update mistake status");
      await refreshMistakes();
    },
    [refreshMistakes]
  );

  const value = useMemo(
    () => ({
      trades,
      settings,
      mistakeStatuses,
      loading,
      error,
      refreshTrades,
      refreshSettings,
      refreshMistakes,
      createTrade,
      updateTrade,
      deleteTrade,
      updateSettings,
      setMistakeStatus,
    }),
    [
      trades,
      settings,
      mistakeStatuses,
      loading,
      error,
      refreshTrades,
      refreshSettings,
      refreshMistakes,
      createTrade,
      updateTrade,
      deleteTrade,
      updateSettings,
      setMistakeStatus,
    ]
  );

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error("useAppData must be used within AppDataProvider");
  return ctx;
}
