"use client";

import { useMemo, useState } from "react";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, StatCard, EmptyState, Spinner, Badge, PnlText } from "@/components/ui/kit";
import { DateRangeFilter } from "@/components/DateRangeFilter";
import {
  computeDashboardStats,
  equityCurve,
  groupPnlByDay,
  rangeForFilter,
  filterTradesByRange,
  DateFilterKey,
} from "@/lib/analytics";
import { fmtMoney, fmtNum, fmtPercent } from "@/lib/format";
import { formatDate, formatTime } from "@/lib/timezone";
import { generateInsights } from "@/lib/insights";
import Link from "next/link";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Cell,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

export default function DashboardPage() {
  const { trades, settings, loading } = useAppData();
  const [filter, setFilter] = useState<DateFilterKey>("All Time");
  const [custom, setCustom] = useState({ from: "", to: "" });

  const filtered = useMemo(() => {
    const { from, to } = rangeForFilter(filter, custom);
    return filterTradesByRange(trades, from, to);
  }, [trades, filter, custom]);

  const stats = useMemo(() => computeDashboardStats(filtered), [filtered]);
  const equity = useMemo(() => equityCurve(filtered), [filtered]);
  const pnlByDay = useMemo(() => groupPnlByDay(filtered), [filtered]);
  const currency = settings?.currency || "USD";

  const recent = useMemo(
    () =>
      [...trades]
        .sort((a, b) => (a.tradeDate + a.tradeTime < b.tradeDate + b.tradeTime ? 1 : -1))
        .slice(0, 5),
    [trades]
  );

  const insights = useMemo(() => generateInsights(trades), [trades]);

  if (loading) return <Spinner />;

  if (trades.length === 0) {
    return (
      <div className="animate-fade-in">
        <SectionTitle title="Dashboard" subtitle="Your trading performance at a glance." />
        <EmptyState
          title="No trades yet"
          message="Start journaling your trades to unlock automatic performance statistics, equity curves and insights."
          action={
            <Link
              href="/trades/new"
              className="inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold"
              style={{ background: "var(--gold)", color: "#15120a" }}
            >
              + Add Your First Trade
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <SectionTitle title="Dashboard" subtitle="Your trading performance at a glance." />
      </div>

      <Card>
        <DateRangeFilter value={filter} onChange={setFilter} custom={custom} onCustomChange={setCustom} />
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard label="Total Trades" value={String(stats.totalTrades)} />
        <StatCard
          label="Net P/L"
          value={fmtMoney(stats.netPnl, currency)}
          tone={stats.netPnl > 0 ? "profit" : stats.netPnl < 0 ? "loss" : "neutral"}
        />
        <StatCard label="Total Profit" value={fmtMoney(stats.totalProfit, currency)} tone="profit" />
        <StatCard label="Total Loss" value={fmtMoney(-stats.totalLoss, currency)} tone="loss" />
        <StatCard label="Win Rate" value={fmtPercent(stats.winRate)} tone="gold" />
        <StatCard label="Winning Trades" value={String(stats.winningTrades)} tone="profit" />
        <StatCard label="Losing Trades" value={String(stats.losingTrades)} tone="loss" />
        <StatCard label="Break-Even Trades" value={String(stats.breakEvenTrades)} />
        <StatCard label="Avg Profit" value={fmtMoney(stats.avgProfit, currency)} tone="profit" />
        <StatCard label="Avg Loss" value={fmtMoney(-stats.avgLoss, currency)} tone="loss" />
        <StatCard label="Largest Win" value={fmtMoney(stats.largestWin, currency)} tone="profit" />
        <StatCard label="Largest Loss" value={fmtMoney(stats.largestLoss, currency)} tone="loss" />
        <StatCard label="Avg Risk:Reward" value={stats.avgRR ? `1 : ${fmtNum(stats.avgRR)}` : "—"} tone="blue" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <SectionTitle title="Equity Curve" subtitle="Cumulative P/L over time" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={equity}>
                <defs>
                  <linearGradient id="equityFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--gold)" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="var(--gold)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="label" stroke="var(--text-muted)" fontSize={11} tickLine={false} />
                <YAxis stroke="var(--text-muted)" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: "var(--bg-elevated)", border: "1px solid var(--border-strong)", borderRadius: 10, fontSize: 12 }}
                  formatter={(v) => fmtMoney(Number(v), currency)}
                />
                <Area type="monotone" dataKey="value" stroke="var(--gold)" strokeWidth={2} fill="url(#equityFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <SectionTitle title="Profit / Loss by Day" subtitle="Daily net result" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pnlByDay}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="label" stroke="var(--text-muted)" fontSize={11} tickLine={false} />
                <YAxis stroke="var(--text-muted)" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: "var(--bg-elevated)", border: "1px solid var(--border-strong)", borderRadius: 10, fontSize: 12 }}
                  formatter={(v) => fmtMoney(Number(v), currency)}
                />
                <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
                  {pnlByDay.map((entry, idx) => (
                    <Cell key={idx} fill={entry.pnl >= 0 ? "var(--profit)" : "var(--loss)"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {insights.length > 0 && (
        <Card>
          <SectionTitle title="Trading Insights" subtitle="Patterns detected from your own recorded data." />
          <ul className="space-y-2">
            {insights.map((insight, i) => (
              <li
                key={i}
                className="rounded-xl border px-3.5 py-2.5 text-sm"
                style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--gold-soft)" }}
              >
                💡 {insight}
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Card>
        <SectionTitle
          title="Recent Trades"
          subtitle="Latest 5 journal entries"
          action={
            <Link href="/history" className="text-xs font-semibold" style={{ color: "var(--gold)" }}>
              View all →
            </Link>
          }
        />
        <div className="space-y-2">
          {recent.map((t) => (
            <Link
              key={t.id}
              href={`/trades/${t.id}`}
              className="flex items-center justify-between rounded-xl border px-3.5 py-3 text-sm transition hover:opacity-90"
              style={{ borderColor: "var(--border)" }}
            >
              <div className="flex items-center gap-3">
                <Badge tone={t.direction === "BUY" ? "profit" : "loss"}>{t.direction}</Badge>
                <div>
                  <p className="font-medium" style={{ color: "var(--text-primary)" }}>
                    {t.instrument === "Other" ? t.customInstrument : t.instrument}
                  </p>
                  <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                    {formatDate(t.tradeDate, settings?.dateFormat)} · {formatTime(t.tradeTime)}
                  </p>
                </div>
              </div>
              <PnlText value={t.pnlUsd} currency={currency} />
            </Link>
          ))}
        </div>
      </Card>
    </div>
  );
}
