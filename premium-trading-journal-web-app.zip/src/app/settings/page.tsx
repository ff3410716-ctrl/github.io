"use client";

import { useRef, useState } from "react";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, Label, Input, Select, Button, ConfirmDialog, Spinner } from "@/components/ui/kit";
import { CURRENCIES, DATE_FORMATS, TIME_ZONES, INSTRUMENTS } from "@/lib/constants";
import { exportTradesCSV } from "@/lib/export";
import { useRouter } from "next/navigation";

export default function SettingsPage() {
  const { settings, updateSettings, trades, refreshTrades, refreshSettings, refreshMistakes, loading } = useAppData();
  const router = useRouter();
  const [theme, setTheme] = useState<string>(typeof window !== "undefined" ? localStorage.getItem("tj-theme") || "dark" : "dark");
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState({
    currency: settings?.currency || "USD",
    timeZone: settings?.timeZone || "Asia/Karachi",
    dateFormat: settings?.dateFormat || "dd MMMM yyyy",
    defaultInstrument: settings?.defaultInstrument || "XAUUSD",
    weeklyTradeLimit: settings?.weeklyTradeLimit?.toString() ?? "",
    dailyMaxLoss: settings?.dailyMaxLoss?.toString() ?? "",
    monthlyProfitTarget: settings?.monthlyProfitTarget?.toString() ?? "",
    minQualityScore: settings?.minQualityScore?.toString() ?? "",
  });

  function applyTheme(t: string) {
    setTheme(t);
    localStorage.setItem("tj-theme", t);
    document.documentElement.classList.toggle("light", t === "light");
  }

  async function saveSettings() {
    setSaving(true);
    try {
      await updateSettings({
        theme,
        currency: form.currency,
        timeZone: form.timeZone,
        dateFormat: form.dateFormat,
        defaultInstrument: form.defaultInstrument,
        weeklyTradeLimit: form.weeklyTradeLimit ? Number(form.weeklyTradeLimit) : null,
        dailyMaxLoss: form.dailyMaxLoss ? Number(form.dailyMaxLoss) : null,
        monthlyProfitTarget: form.monthlyProfitTarget ? Number(form.monthlyProfitTarget) : null,
        minQualityScore: form.minQualityScore ? Number(form.minQualityScore) : null,
      });
      setSavedMsg(true);
      setTimeout(() => setSavedMsg(false), 2000);
    } finally {
      setSaving(false);
    }
  }

  async function handleRestore(file: File) {
    setRestoring(true);
    try {
      const text = await file.text();
      const json = JSON.parse(text);
      const res = await fetch("/api/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(json),
      });
      if (!res.ok) throw new Error("Restore failed");
      await Promise.all([refreshTrades(), refreshSettings(), refreshMistakes()]);
      alert("Backup restored successfully.");
    } catch {
      alert("Could not restore this backup file. Please check the file and try again.");
    } finally {
      setRestoring(false);
    }
  }

  async function handleClearAll() {
    await fetch("/api/data/clear", { method: "POST" });
    await Promise.all([refreshTrades(), refreshSettings(), refreshMistakes()]);
    setConfirmClear(false);
    router.push("/");
  }

  if (loading) return <Spinner />;

  return (
    <div className="animate-fade-in space-y-5 pb-10">
      <SectionTitle title="Settings" subtitle="Configure your journal preferences, goals and data." />

      <Card>
        <SectionTitle title="Appearance" />
        <div className="flex gap-3">
          {(["dark", "light"] as const).map((t) => (
            <button
              key={t}
              onClick={() => applyTheme(t)}
              className="flex-1 rounded-xl border px-4 py-3 text-sm font-semibold capitalize"
              style={{
                borderColor: theme === t ? "var(--gold)" : "var(--border)",
                background: theme === t ? "var(--gold-soft)" : "transparent",
                color: theme === t ? "var(--gold)" : "var(--text-secondary)",
              }}
            >
              {t} Theme
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <SectionTitle title="General Preferences" />
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label>Account Currency</Label>
            <Select value={form.currency} onChange={(e) => setForm((f) => ({ ...f, currency: e.target.value }))}>
              {CURRENCIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Time Zone</Label>
            <Select value={form.timeZone} onChange={(e) => setForm((f) => ({ ...f, timeZone: e.target.value }))}>
              {TIME_ZONES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Date Format</Label>
            <Select value={form.dateFormat} onChange={(e) => setForm((f) => ({ ...f, dateFormat: e.target.value }))}>
              {DATE_FORMATS.map((d) => (
                <option key={d.value} value={d.value}>
                  {d.label}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Default Trading Instrument</Label>
            <Select value={form.defaultInstrument} onChange={(e) => setForm((f) => ({ ...f, defaultInstrument: e.target.value }))}>
              {INSTRUMENTS.map((i) => (
                <option key={i} value={i}>
                  {i}
                </option>
              ))}
            </Select>
          </div>
        </div>
      </Card>

      <Card>
        <SectionTitle title="Personal Trading Goals" subtitle="Tracking targets only — not automated controls." />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Label>Weekly Trade Limit</Label>
            <Input type="number" value={form.weeklyTradeLimit} onChange={(e) => setForm((f) => ({ ...f, weeklyTradeLimit: e.target.value }))} placeholder="e.g. 15" />
          </div>
          <div>
            <Label>Daily Maximum Loss ($)</Label>
            <Input type="number" value={form.dailyMaxLoss} onChange={(e) => setForm((f) => ({ ...f, dailyMaxLoss: e.target.value }))} placeholder="e.g. 100" />
          </div>
          <div>
            <Label>Monthly Profit Target ($)</Label>
            <Input type="number" value={form.monthlyProfitTarget} onChange={(e) => setForm((f) => ({ ...f, monthlyProfitTarget: e.target.value }))} placeholder="e.g. 1000" />
          </div>
          <div>
            <Label>Minimum Trade Quality Score</Label>
            <Input type="number" min={1} max={10} value={form.minQualityScore} onChange={(e) => setForm((f) => ({ ...f, minQualityScore: e.target.value }))} placeholder="e.g. 7" />
          </div>
        </div>
      </Card>

      <div className="flex items-center justify-end gap-3">
        {savedMsg && (
          <span className="text-xs font-medium" style={{ color: "var(--profit)" }}>
            Settings saved!
          </span>
        )}
        <Button onClick={saveSettings} disabled={saving}>
          {saving ? "Saving..." : "Save Settings"}
        </Button>
      </div>

      <Card>
        <SectionTitle title="Backup & Restore" subtitle="Your data lives in your personal database — back it up anytime." />
        <div className="flex flex-wrap gap-3">
          <Button variant="secondary" onClick={() => window.open("/api/backup", "_blank")}>
            Download JSON Backup
          </Button>
          <Button variant="secondary" onClick={() => exportTradesCSV(trades)}>
            Export Trades as CSV
          </Button>
          <Button variant="secondary" onClick={() => fileRef.current?.click()} disabled={restoring}>
            {restoring ? "Restoring..." : "Restore from Backup"}
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            hidden
            onChange={(e) => e.target.files?.[0] && handleRestore(e.target.files[0])}
          />
        </div>
        <p className="mt-2 text-xs" style={{ color: "var(--text-muted)" }}>
          Restoring a backup will replace all current trades, screenshots, mistake statuses and daily reviews.
        </p>
      </Card>

      <Card>
        <SectionTitle title="Danger Zone" />
        <Button variant="danger" onClick={() => setConfirmClear(true)}>
          Delete All Data
        </Button>
        <p className="mt-2 text-xs" style={{ color: "var(--text-muted)" }}>
          Permanently deletes every trade, screenshot, review and mistake record. This cannot be undone.
        </p>
      </Card>

      <ConfirmDialog
        open={confirmClear}
        title="Delete all data?"
        message="This will permanently erase every trade, screenshot and journal record stored in this app. This action is irreversible."
        confirmLabel="Yes, Delete Everything"
        danger
        onConfirm={handleClearAll}
        onCancel={() => setConfirmClear(false)}
      />
    </div>
  );
}
