"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, Input, Select, TextArea, Button, Badge, PnlText, Spinner } from "@/components/ui/kit";
import { getNowParts, formatDate, dayOfWeek } from "@/lib/timezone";
import { YES_NO_PARTIAL } from "@/lib/constants";
import { DailyReview } from "@/lib/types";
import { fmtMoney } from "@/lib/format";

export default function DailyReviewPage() {
  const { trades, settings, loading } = useAppData();
  const now = useMemo(() => getNowParts(settings?.timeZone || "Asia/Karachi"), [settings?.timeZone]);
  const [date, setDate] = useState(now.date);
  const [review, setReview] = useState<DailyReview | null>(null);
  const [followedPlan, setFollowedPlan] = useState("Yes");
  const [learned, setLearned] = useState("");
  const [improveTomorrow, setImproveTomorrow] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [pastReviews, setPastReviews] = useState<DailyReview[]>([]);

  const dayTrades = useMemo(() => trades.filter((t) => t.tradeDate === date), [trades, date]);
  const netPnl = useMemo(() => dayTrades.reduce((s, t) => s + (t.pnlUsd ?? 0), 0), [dayTrades]);
  const currency = settings?.currency || "USD";

  const loadReview = useCallback(async (d: string) => {
    const res = await fetch(`/api/daily-review?date=${d}`);
    const data = await res.json();
    const r = data.review as DailyReview | null;
    setReview(r);
    setFollowedPlan(r?.followedPlan || "Yes");
    setLearned(r?.learned || "");
    setImproveTomorrow(r?.improveTomorrow || "");
  }, []);

  const loadPast = useCallback(async () => {
    const res = await fetch(`/api/daily-review`);
    const data = await res.json();
    setPastReviews(data.reviews ?? []);
  }, []);

  useEffect(() => {
    loadReview(date);
  }, [date, loadReview]);

  useEffect(() => {
    loadPast();
  }, [loadPast]);

  async function saveReview() {
    setSaving(true);
    setSaved(false);
    await fetch("/api/daily-review", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ date, followedPlan, learned, improveTomorrow }),
    });
    await loadPast();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  if (loading) return <Spinner />;

  return (
    <div className="animate-fade-in space-y-5">
      <SectionTitle title="Daily Trading Review" subtitle="Reflect on each trading day — automatically calculated from your saved trades." />

      <Card>
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <p className="mb-1.5 text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
              Review Date
            </p>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <Badge tone="blue">{dayOfWeek(date)}</Badge>
          <Badge tone="gold">{formatDate(date, settings?.dateFormat)}</Badge>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Card>
          <p className="text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
            Trades Taken
          </p>
          <p className="mt-2 text-2xl font-bold" style={{ color: "var(--text-primary)" }}>
            {dayTrades.length}
          </p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
            Total Profit / Loss
          </p>
          <p className="mt-2 text-2xl font-bold">
            <PnlText value={dayTrades.length ? netPnl : null} currency={currency} />
          </p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
            Wins / Losses / BE
          </p>
          <p className="mt-2 text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
            {dayTrades.filter((t) => t.result === "PROFIT").length} / {dayTrades.filter((t) => t.result === "LOSS").length} /{" "}
            {dayTrades.filter((t) => t.result === "BREAK_EVEN").length}
          </p>
        </Card>
      </div>

      {dayTrades.length > 0 && (
        <Card>
          <SectionTitle title="Trades on this day" />
          <div className="space-y-1.5">
            {dayTrades.map((t) => (
              <div key={t.id} className="flex items-center justify-between rounded-lg px-3 py-2 text-sm" style={{ background: "var(--card-hover)" }}>
                <span style={{ color: "var(--text-primary)" }}>
                  {t.instrument === "Other" ? t.customInstrument : t.instrument} · {t.direction}
                </span>
                <span className="font-semibold">{fmtMoney(t.pnlUsd, currency)}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card>
        <SectionTitle title="Reflection" subtitle={review ? "Last saved — editable anytime." : "Not saved yet for this date."} />
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <p className="mb-1.5 text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
              Did you follow your trading plan?
            </p>
            <Select value={followedPlan} onChange={(e) => setFollowedPlan(e.target.value)}>
              {YES_NO_PARTIAL.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </Select>
          </div>
          <div />
          <div>
            <p className="mb-1.5 text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
              What did you learn today?
            </p>
            <TextArea rows={3} value={learned} onChange={(e) => setLearned(e.target.value)} />
          </div>
          <div>
            <p className="mb-1.5 text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
              What will you improve tomorrow?
            </p>
            <TextArea rows={3} value={improveTomorrow} onChange={(e) => setImproveTomorrow(e.target.value)} />
          </div>
        </div>
        <div className="mt-4 flex items-center justify-end gap-3">
          {saved && (
            <span className="text-xs font-medium" style={{ color: "var(--profit)" }}>
              Saved!
            </span>
          )}
          <Button onClick={saveReview} disabled={saving}>
            {saving ? "Saving..." : "Save Review"}
          </Button>
        </div>
      </Card>

      {pastReviews.length > 0 && (
        <Card>
          <SectionTitle title="Past Reviews" />
          <div className="space-y-1.5">
            {pastReviews
              .filter((r) => r.date !== date)
              .slice(0, 10)
              .map((r) => (
                <button
                  key={r.date}
                  onClick={() => setDate(r.date)}
                  className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm"
                  style={{ background: "var(--card-hover)" }}
                >
                  <span style={{ color: "var(--text-primary)" }}>{formatDate(r.date, settings?.dateFormat)}</span>
                  <Badge tone={r.followedPlan === "Yes" ? "profit" : r.followedPlan === "No" ? "loss" : "neutral"}>
                    Plan: {r.followedPlan || "—"}
                  </Badge>
                </button>
              ))}
          </div>
        </Card>
      )}
    </div>
  );
}
