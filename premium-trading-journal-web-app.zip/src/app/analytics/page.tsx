"use client";

import { useMemo } from "react";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, StatCard, EmptyState, Spinner } from "@/components/ui/kit";
import {
  computeDashboardStats,
  performanceByKey,
  groupPnlByDay,
  groupByWeekLabel,
  groupByMonthLabel,
  consecutiveStreaks,
  maxDrawdown,
} from "@/lib/analytics";
import { fmtMoney, fmtPercent, fmtNum } from "@/lib/format";
import Link from "next/link";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Legend,
} from "recharts";

function PerfBarChart({ data, currency }: { data: { label: string; pnl: number }[]; currency: string }) {
  return (
    <div className="h-60">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
          <XAxis dataKey="label" stroke="var(--text-muted)" fontSize={11} tickLine={false} />
          <YAxis stroke="var(--text-muted)" fontSize={11} tickLine={false} />
          <Tooltip
            contentStyle={{ background: "var(--bg-elevated)", border: "1px solid var(--border-strong)", borderRadius: 10, fontSize: 12 }}
            formatter={(v) => fmtMoney(Number(v), currency)}
          />
          <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
            {data.map((d, i) => (
              <Cell key={i} fill={d.pnl >= 0 ? "var(--profit)" : "var(--loss)"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function KeyPerfTable({ title, subtitle, data, currency }: { title: string; subtitle?: string; data: ReturnType<typeof performanceByKey>; currency: string }) {
  return (
    <Card>
      <SectionTitle title={title} subtitle={subtitle} />
      {data.length === 0 ? (
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>
          Not enough data yet.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr style={{ color: "var(--text-muted)" }} className="text-xs uppercase">
                <th className="pb-2">Name</th>
                <th className="pb-2">Trades</th>
                <th className="pb-2">Win Rate</th>
                <th className="pb-2">Net P/L</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row) => (
                <tr key={row.key} className="border-t" style={{ borderColor: "var(--border)" }}>
                  <td className="py-2 font-medium" style={{ color: "var(--text-primary)" }}>
                    {row.key}
                  </td>
                  <td className="py-2" style={{ color: "var(--text-secondary)" }}>
                    {row.trades}
                  </td>
                  <td className="py-2" style={{ color: "var(--text-secondary)" }}>
                    {fmtPercent(row.winRate)}
                  </td>
                  <td className="py-2 font-semibold" style={{ color: row.netPnl >= 0 ? "var(--profit)" : "var(--loss)" }}>
                    {fmtMoney(row.netPnl, currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

export default function AnalyticsPage() {
  const { trades, settings, loading } = useAppData();
  const currency = settings?.currency || "USD";

  const stats = useMemo(() => computeDashboardStats(trades), [trades]);
  const byInstrument = useMemo(() => performanceByKey(trades, (t) => (t.instrument === "Other" ? t.customInstrument || "Other" : t.instrument)), [trades]);
  const bySession = useMemo(() => performanceByKey(trades, (t) => t.session || "Unspecified"), [trades]);
  const byStrategy = useMemo(() => performanceByKey(trades, (t) => t.strategy || "Unspecified"), [trades]);
  const byDirection = useMemo(() => performanceByKey(trades, (t) => t.direction), [trades]);
  const dailyPnl = useMemo(() => groupPnlByDay(trades), [trades]);
  const weeklyPnl = useMemo(() => groupByWeekLabel(trades), [trades]);
  const monthlyPnl = useMemo(() => groupByMonthLabel(trades), [trades]);
  const streaks = useMemo(() => consecutiveStreaks(trades), [trades]);
  const drawdown = useMemo(() => maxDrawdown(trades), [trades]);

  const pieData = [
    { name: "Wins", value: stats.winningTrades, color: "var(--profit)" },
    { name: "Losses", value: stats.losingTrades, color: "var(--loss)" },
    { name: "Break Even", value: stats.breakEvenTrades, color: "var(--neutral)" },
  ];

  if (loading) return <Spinner />;

  if (trades.length === 0) {
    return (
      <div>
        <SectionTitle title="Performance Analytics" subtitle="Deep insights into your trading edge." />
        <EmptyState
          title="No analytics yet"
          message="Add a few trades to unlock win-rate analysis, session performance, instrument breakdowns and more."
          action={
            <Link href="/trades/new" className="rounded-xl px-4 py-2.5 text-sm font-semibold" style={{ background: "var(--gold)", color: "#15120a" }}>
              + Add Trade
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-5">
      <SectionTitle title="Performance Analytics" subtitle="Understand which trading conditions work best for you." />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label="Win Rate" value={fmtPercent(stats.winRate)} tone="gold" />
        <StatCard label="Avg Risk:Reward" value={stats.avgRR ? `1:${fmtNum(stats.avgRR)}` : "—"} tone="blue" />
        <StatCard label="Max Win Streak" value={String(streaks.maxWinStreak)} tone="profit" />
        <StatCard label="Max Loss Streak" value={String(streaks.maxLossStreak)} tone="loss" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <SectionTitle title="Win Rate Analysis" subtitle="Wins vs losses vs break-even" />
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3}>
                  {pieData.map((d, i) => (
                    <Cell key={i} fill={d.color} />
                  ))}
                </Pie>
                <Legend wrapperStyle={{ fontSize: 12, color: "var(--text-secondary)" }} />
                <Tooltip contentStyle={{ background: "var(--bg-elevated)", border: "1px solid var(--border-strong)", borderRadius: 10, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <SectionTitle title="Maximum Drawdown" subtitle="Based on recorded balance-after values" />
          <div className="flex h-60 flex-col items-center justify-center">
            <p className="text-4xl font-bold" style={{ color: drawdown > 0 ? "var(--loss)" : "var(--text-primary)" }}>
              {fmtPercent(drawdown)}
            </p>
            <p className="mt-2 max-w-xs text-center text-xs" style={{ color: "var(--text-muted)" }}>
              {drawdown === 0
                ? "Add balance before/after values on your trades to calculate drawdown."
                : "Largest peak-to-trough decline in your account balance."}
            </p>
          </div>
        </Card>
      </div>

      <Card>
        <SectionTitle title="Daily Performance" subtitle="Net P/L per trading day" />
        <PerfBarChart data={dailyPnl} currency={currency} />
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <SectionTitle title="Weekly Performance" />
          <PerfBarChart data={weeklyPnl} currency={currency} />
        </Card>
        <Card>
          <SectionTitle title="Monthly Performance" />
          <PerfBarChart data={monthlyPnl} currency={currency} />
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <KeyPerfTable title="BUY vs SELL Performance" data={byDirection} currency={currency} />
        <KeyPerfTable title="Trading Session Performance" data={bySession} currency={currency} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <KeyPerfTable title="Instrument-wise Performance" data={byInstrument} currency={currency} />
        <KeyPerfTable title="Strategy-wise Performance" data={byStrategy} currency={currency} />
      </div>
    </div>
  );
}
