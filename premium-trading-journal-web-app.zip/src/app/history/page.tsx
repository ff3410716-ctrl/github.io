"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, Badge, Input, Select, Button, EmptyState, Spinner, ConfirmDialog, PnlText } from "@/components/ui/kit";
import { formatDate, formatTime } from "@/lib/timezone";
import { Trade } from "@/lib/types";

type SortKey = "newest" | "oldest";

export default function HistoryPage() {
  const { trades, settings, deleteTrade, loading } = useAppData();
  const [search, setSearch] = useState("");
  const [instrumentFilter, setInstrumentFilter] = useState("All");
  const [directionFilter, setDirectionFilter] = useState("All");
  const [resultFilter, setResultFilter] = useState("All");
  const [dateFilter, setDateFilter] = useState("");
  const [sort, setSort] = useState<SortKey>("newest");
  const [deleteTarget, setDeleteTarget] = useState<Trade | null>(null);

  const instruments = useMemo(() => Array.from(new Set(trades.map((t) => t.instrument))), [trades]);

  const filtered = useMemo(() => {
    let list = [...trades];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (t) =>
          t.instrument.toLowerCase().includes(q) ||
          (t.customInstrument || "").toLowerCase().includes(q) ||
          (t.strategy || "").toLowerCase().includes(q) ||
          (t.notes || "").toLowerCase().includes(q)
      );
    }
    if (instrumentFilter !== "All") list = list.filter((t) => t.instrument === instrumentFilter);
    if (directionFilter !== "All") list = list.filter((t) => t.direction === directionFilter);
    if (resultFilter !== "All") list = list.filter((t) => t.result === resultFilter);
    if (dateFilter) list = list.filter((t) => t.tradeDate === dateFilter);

    list.sort((a, b) => {
      const ka = a.tradeDate + a.tradeTime;
      const kb = b.tradeDate + b.tradeTime;
      return sort === "newest" ? (ka < kb ? 1 : -1) : ka < kb ? -1 : 1;
    });
    return list;
  }, [trades, search, instrumentFilter, directionFilter, resultFilter, dateFilter, sort]);

  const currency = settings?.currency || "USD";

  async function confirmDelete() {
    if (!deleteTarget) return;
    await deleteTrade(deleteTarget.id);
    setDeleteTarget(null);
  }

  if (loading) return <Spinner />;

  return (
    <div className="animate-fade-in space-y-5">
      <SectionTitle title="Trade History" subtitle="Search, filter and manage every recorded trade." />

      <Card>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <Input placeholder="Search instrument, strategy, notes..." value={search} onChange={(e) => setSearch(e.target.value)} className="lg:col-span-2" />
          <Select value={instrumentFilter} onChange={(e) => setInstrumentFilter(e.target.value)}>
            <option value="All">All Instruments</option>
            {instruments.map((i) => (
              <option key={i} value={i}>
                {i}
              </option>
            ))}
          </Select>
          <Select value={directionFilter} onChange={(e) => setDirectionFilter(e.target.value)}>
            <option value="All">BUY / SELL</option>
            <option value="BUY">BUY</option>
            <option value="SELL">SELL</option>
          </Select>
          <Select value={resultFilter} onChange={(e) => setResultFilter(e.target.value)}>
            <option value="All">All Results</option>
            <option value="PROFIT">Profit</option>
            <option value="LOSS">Loss</option>
            <option value="BREAK_EVEN">Break Even</option>
          </Select>
          <Input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} />
        </div>
        <div className="mt-3 flex items-center justify-between">
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            {filtered.length} of {trades.length} trades
          </p>
          <div className="flex gap-2">
            <Button variant={sort === "newest" ? "primary" : "secondary"} onClick={() => setSort("newest")} className="!px-3 !py-1.5 !text-xs">
              Newest First
            </Button>
            <Button variant={sort === "oldest" ? "primary" : "secondary"} onClick={() => setSort("oldest")} className="!px-3 !py-1.5 !text-xs">
              Oldest First
            </Button>
          </div>
        </div>
      </Card>

      {filtered.length === 0 ? (
        <EmptyState
          title={trades.length === 0 ? "No trades yet" : "No trades match your filters"}
          message={trades.length === 0 ? "Add your first trade to build your trading history." : "Try adjusting your search or filters."}
          action={
            trades.length === 0 ? (
              <Link href="/trades/new" className="rounded-xl px-4 py-2.5 text-sm font-semibold" style={{ background: "var(--gold)", color: "#15120a" }}>
                + Add Trade
              </Link>
            ) : undefined
          }
        />
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden overflow-x-auto md:block">
            <table className="w-full text-left text-sm">
              <thead>
                <tr style={{ color: "var(--text-muted)" }} className="text-xs uppercase tracking-wide">
                  <th className="pb-3 pr-3">Date / Day</th>
                  <th className="pb-3 pr-3">Time</th>
                  <th className="pb-3 pr-3">Instrument</th>
                  <th className="pb-3 pr-3">Direction</th>
                  <th className="pb-3 pr-3">Lot</th>
                  <th className="pb-3 pr-3">Entry</th>
                  <th className="pb-3 pr-3">Exit</th>
                  <th className="pb-3 pr-3">P/L</th>
                  <th className="pb-3 pr-3">Result</th>
                  <th className="pb-3 pr-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((t) => (
                  <tr key={t.id} className="border-t" style={{ borderColor: "var(--border)" }}>
                    <td className="py-3 pr-3" style={{ color: "var(--text-primary)" }}>
                      {formatDate(t.tradeDate, settings?.dateFormat)}
                    </td>
                    <td className="py-3 pr-3" style={{ color: "var(--text-secondary)" }}>
                      {formatTime(t.tradeTime)}
                    </td>
                    <td className="py-3 pr-3 font-medium" style={{ color: "var(--text-primary)" }}>
                      {t.instrument === "Other" ? t.customInstrument : t.instrument}
                    </td>
                    <td className="py-3 pr-3">
                      <Badge tone={t.direction === "BUY" ? "profit" : "loss"}>{t.direction}</Badge>
                    </td>
                    <td className="py-3 pr-3" style={{ color: "var(--text-secondary)" }}>
                      {t.lotSize ?? "—"}
                    </td>
                    <td className="py-3 pr-3" style={{ color: "var(--text-secondary)" }}>
                      {t.entryPrice ?? "—"}
                    </td>
                    <td className="py-3 pr-3" style={{ color: "var(--text-secondary)" }}>
                      {t.exitPrice ?? "—"}
                    </td>
                    <td className="py-3 pr-3">
                      <PnlText value={t.pnlUsd} currency={currency} />
                    </td>
                    <td className="py-3 pr-3">
                      <Badge tone={t.result === "PROFIT" ? "profit" : t.result === "LOSS" ? "loss" : "neutral"}>
                        {t.result.replace("_", " ")}
                      </Badge>
                    </td>
                    <td className="py-3 pr-3">
                      <div className="flex gap-2 text-xs font-semibold">
                        <Link href={`/trades/${t.id}`} style={{ color: "var(--blue)" }}>
                          View
                        </Link>
                        <button onClick={() => setDeleteTarget(t)} style={{ color: "var(--loss)" }}>
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="grid gap-3 md:hidden">
            {filtered.map((t) => (
              <Link key={t.id} href={`/trades/${t.id}`}>
                <Card hover>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge tone={t.direction === "BUY" ? "profit" : "loss"}>{t.direction}</Badge>
                      <span className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
                        {t.instrument === "Other" ? t.customInstrument : t.instrument}
                      </span>
                    </div>
                    <Badge tone={t.result === "PROFIT" ? "profit" : t.result === "LOSS" ? "loss" : "neutral"}>
                      {t.result.replace("_", " ")}
                    </Badge>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs" style={{ color: "var(--text-muted)" }}>
                    <span>
                      {formatDate(t.tradeDate, settings?.dateFormat)} · {formatTime(t.tradeTime)}
                    </span>
                    <PnlText value={t.pnlUsd} currency={currency} />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete this trade?"
        message="This will permanently remove the trade record and its screenshots."
        confirmLabel="Delete Trade"
        danger
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
