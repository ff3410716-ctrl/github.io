"use client";

import { useMemo } from "react";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, Badge, Select, EmptyState, Spinner } from "@/components/ui/kit";
import { MISTAKE_STATUSES } from "@/lib/constants";
import { format, startOfWeek, startOfMonth } from "date-fns";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from "recharts";
import Link from "next/link";

function mistakeLabel(trade: { mistake: string | null; mistakeCustom: string | null }): string | null {
  if (!trade.mistake || trade.mistake === "None") return null;
  if (trade.mistake === "Other") return trade.mistakeCustom || "Other";
  return trade.mistake;
}

export default function MistakeTrackerPage() {
  const { trades, mistakeStatuses, setMistakeStatus, loading } = useAppData();

  const mistakeTrades = useMemo(
    () => trades.map((t) => ({ trade: t, label: mistakeLabel(t) })).filter((x) => x.label) as { trade: (typeof trades)[number]; label: string }[],
    [trades]
  );

  const counts = useMemo(() => {
    const map = new Map<string, number>();
    for (const { label } of mistakeTrades) map.set(label, (map.get(label) ?? 0) + 1);
    return Array.from(map.entries())
      .map(([label, count]) => ({ label, count }))
      .sort((a, b) => b.count - a.count);
  }, [mistakeTrades]);

  const mostRepeated = counts[0];

  const weeklyByMistake = useMemo(() => {
    const map = new Map<string, number>();
    const now = new Date();
    const wkStart = startOfWeek(now, { weekStartsOn: 1 });
    for (const { trade, label } of mistakeTrades) {
      const d = new Date(trade.tradeDate + "T00:00:00");
      if (d >= wkStart) map.set(label, (map.get(label) ?? 0) + 1);
    }
    return map;
  }, [mistakeTrades]);

  const monthlyByMistake = useMemo(() => {
    const map = new Map<string, number>();
    const now = new Date();
    const moStart = startOfMonth(now);
    for (const { trade, label } of mistakeTrades) {
      const d = new Date(trade.tradeDate + "T00:00:00");
      if (d >= moStart) map.set(label, (map.get(label) ?? 0) + 1);
    }
    return map;
  }, [mistakeTrades]);

  function statusFor(mistake: string) {
    return mistakeStatuses.find((m) => m.mistake === mistake)?.status || "Not Improved";
  }

  if (loading) return <Spinner />;

  return (
    <div className="animate-fade-in space-y-5">
      <SectionTitle title="Mistake Tracker" subtitle="Automatically organized from your journal entries — prevent repeating costly mistakes." />

      {counts.length === 0 ? (
        <EmptyState
          title="No mistakes logged yet"
          message="Great discipline so far! Mistakes you record on each trade will be analyzed here automatically."
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Card>
              <p className="text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
                Most Repeated Mistake
              </p>
              <p className="mt-2 text-xl font-bold" style={{ color: "var(--loss)" }}>
                {mostRepeated?.label || "—"}
              </p>
              <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
                {mostRepeated ? `${mostRepeated.count} occurrences` : ""}
              </p>
            </Card>
            <Card>
              <p className="text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
                Total Mistake Instances
              </p>
              <p className="mt-2 text-xl font-bold" style={{ color: "var(--text-primary)" }}>
                {mistakeTrades.length}
              </p>
            </Card>
            <Card>
              <p className="text-xs font-medium uppercase" style={{ color: "var(--text-secondary)" }}>
                Unique Mistake Types
              </p>
              <p className="mt-2 text-xl font-bold" style={{ color: "var(--text-primary)" }}>
                {counts.length}
              </p>
            </Card>
          </div>

          <Card>
            <SectionTitle title="Mistake Frequency" subtitle="How often each mistake has occurred" />
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={counts} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis type="number" stroke="var(--text-muted)" fontSize={11} allowDecimals={false} />
                  <YAxis type="category" dataKey="label" stroke="var(--text-muted)" fontSize={11} width={160} />
                  <Tooltip contentStyle={{ background: "var(--bg-elevated)", border: "1px solid var(--border-strong)", borderRadius: 10, fontSize: 12 }} />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                    {counts.map((_, i) => (
                      <Cell key={i} fill="var(--loss)" />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card>
            <SectionTitle title="Improvement Tracking" subtitle="Mark your progress on each recurring mistake" />
            <div className="space-y-2">
              {counts.map((c) => (
                <div key={c.label} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border px-3.5 py-3" style={{ borderColor: "var(--border)" }}>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
                      {c.label}
                    </p>
                    <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                      {c.count} total · {weeklyByMistake.get(c.label) ?? 0} this week · {monthlyByMistake.get(c.label) ?? 0} this month
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone={statusFor(c.label) === "Fixed" ? "profit" : statusFor(c.label) === "Improving" ? "gold" : "loss"}>
                      {statusFor(c.label)}
                    </Badge>
                    <Select
                      value={statusFor(c.label)}
                      onChange={(e) => setMistakeStatus(c.label, e.target.value)}
                      className="!w-auto !py-1.5 !text-xs"
                    >
                      {MISTAKE_STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </Select>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <SectionTitle title="Related Trades" subtitle="Click through to review the full trade context" />
            <div className="space-y-1.5">
              {mistakeTrades.slice(0, 8).map(({ trade, label }) => (
                <Link
                  key={trade.id}
                  href={`/trades/${trade.id}`}
                  className="flex items-center justify-between rounded-lg px-3 py-2 text-sm"
                  style={{ background: "var(--card-hover)" }}
                >
                  <span style={{ color: "var(--text-primary)" }}>
                    {trade.instrument === "Other" ? trade.customInstrument : trade.instrument} · {format(new Date(trade.tradeDate + "T00:00:00"), "dd MMM yyyy")}
                  </span>
                  <Badge tone="loss">{label}</Badge>
                </Link>
              ))}
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
