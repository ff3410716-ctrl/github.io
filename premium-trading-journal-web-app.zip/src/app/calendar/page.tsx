"use client";

import { useMemo, useState } from "react";
import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isToday,
  format,
  addMonths,
  subMonths,
} from "date-fns";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, Modal, Badge, Spinner, PnlText } from "@/components/ui/kit";
import { dailyNetMap, dayColor } from "@/lib/analytics";
import { formatTime } from "@/lib/timezone";
import { fmtMoney } from "@/lib/format";
import Link from "next/link";
import clsx from "clsx";

export default function CalendarPage() {
  const { trades, settings, loading } = useAppData();
  const [month, setMonth] = useState(new Date());
  const [selected, setSelected] = useState<string | null>(null);

  const netMap = useMemo(() => dailyNetMap(trades), [trades]);

  const days = useMemo(() => {
    const start = startOfWeek(startOfMonth(month), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(month), { weekStartsOn: 1 });
    return eachDayOfInterval({ start, end });
  }, [month]);

  const selectedTrades = useMemo(() => (selected ? trades.filter((t) => t.tradeDate === selected) : []), [selected, trades]);
  const selectedNet = selected ? netMap.get(selected)?.pnl ?? 0 : 0;
  const currency = settings?.currency || "USD";

  if (loading) return <Spinner />;

  const colorFor = (status: string) => {
    switch (status) {
      case "profit":
        return { bg: "var(--profit-soft)", dot: "var(--profit)" };
      case "loss":
        return { bg: "var(--loss-soft)", dot: "var(--loss)" };
      case "neutral":
        return { bg: "var(--neutral-soft)", dot: "var(--neutral)" };
      default:
        return { bg: "transparent", dot: "var(--border-strong)" };
    }
  };

  return (
    <div className="animate-fade-in space-y-5">
      <SectionTitle title="Trading Calendar" subtitle="Green = profitable day · Red = losing day · Yellow = break-even · Grey = no trades" />

      <Card>
        <div className="mb-4 flex items-center justify-between">
          <button onClick={() => setMonth((m) => subMonths(m, 1))} className="rounded-lg px-3 py-1.5 text-sm" style={{ background: "var(--card-hover)", color: "var(--text-secondary)" }}>
            ← Prev
          </button>
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
            {format(month, "MMMM yyyy")}
          </h3>
          <button onClick={() => setMonth((m) => addMonths(m, 1))} className="rounded-lg px-3 py-1.5 text-sm" style={{ background: "var(--card-hover)", color: "var(--text-secondary)" }}>
            Next →
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] font-medium" style={{ color: "var(--text-muted)" }}>
          {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
            <div key={d} className="pb-1">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {days.map((d) => {
            const key = format(d, "yyyy-MM-dd");
            const info = netMap.get(key);
            const status = dayColor(info?.pnl ?? 0, info?.count ?? 0);
            const colors = colorFor(status);
            const inMonth = isSameMonth(d, month);
            return (
              <button
                key={key}
                disabled={!info}
                onClick={() => info && setSelected(key)}
                className={clsx("flex aspect-square flex-col items-center justify-center rounded-xl border text-xs transition", info && "cursor-pointer hover:opacity-80")}
                style={{
                  borderColor: isToday(d) ? "var(--gold)" : "var(--border)",
                  background: colors.bg,
                  opacity: inMonth ? 1 : 0.35,
                }}
              >
                <span style={{ color: "var(--text-primary)" }}>{format(d, "d")}</span>
                {info && (
                  <span className="mt-0.5 h-1.5 w-1.5 rounded-full" style={{ background: colors.dot }} />
                )}
              </button>
            );
          })}
        </div>
      </Card>

      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected ? format(new Date(selected + "T00:00:00"), "dd MMMM yyyy") : ""}>
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            {selectedTrades.length} trade{selectedTrades.length !== 1 ? "s" : ""}
          </p>
          <p className="text-sm font-semibold">
            Net: <PnlText value={selectedNet} currency={currency} />
          </p>
        </div>
        <div className="space-y-2">
          {selectedTrades.map((t) => (
            <Link
              key={t.id}
              href={`/trades/${t.id}`}
              className="flex items-center justify-between rounded-xl border px-3 py-2.5 text-sm"
              style={{ borderColor: "var(--border)" }}
            >
              <div className="flex items-center gap-2">
                <Badge tone={t.direction === "BUY" ? "profit" : "loss"}>{t.direction}</Badge>
                <span style={{ color: "var(--text-primary)" }}>{t.instrument === "Other" ? t.customInstrument : t.instrument}</span>
                <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                  {formatTime(t.tradeTime)}
                </span>
              </div>
              <span className="text-xs font-semibold" style={{ color: "var(--text-secondary)" }}>
                {fmtMoney(t.pnlUsd, currency)}
              </span>
            </Link>
          ))}
        </div>
      </Modal>
    </div>
  );
}
