import { db } from "@/db";
import { trades, screenshots } from "@/db/schema";
import { mapTrade } from "@/lib/db-helpers";
import { desc } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function toStr(v: unknown): string | null {
  if (v === undefined || v === null || v === "") return null;
  return String(v);
}

export async function GET() {
  try {
    const allTrades = await db.select().from(trades).orderBy(desc(trades.tradeDate), desc(trades.tradeTime));
    const allShots = await db.select().from(screenshots);
    const byTrade = new Map<number, typeof allShots>();
    for (const s of allShots) {
      const list = byTrade.get(s.tradeId) ?? [];
      list.push(s);
      byTrade.set(s.tradeId, list);
    }
    const result = allTrades.map((t) => mapTrade(t, byTrade.get(t.id) ?? []));
    return Response.json({ trades: result });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Failed to load trades" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body.tradeDate || !body.tradeTime || !body.instrument || !body.market || !body.direction || !body.result) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    const [created] = await db
      .insert(trades)
      .values({
        tradeDate: body.tradeDate,
        tradeTime: body.tradeTime,
        instrument: body.instrument,
        customInstrument: toStr(body.customInstrument),
        market: body.market,
        direction: body.direction,
        lotSize: toStr(body.lotSize),
        entryPrice: toStr(body.entryPrice),
        stopLoss: toStr(body.stopLoss),
        takeProfit: toStr(body.takeProfit),
        exitPrice: toStr(body.exitPrice),
        pips: toStr(body.pips),
        riskReward: toStr(body.riskReward),
        strategy: toStr(body.strategy),
        session: toStr(body.session),
        result: body.result,
        pnlUsd: toStr(body.pnlUsd),
        balanceBefore: toStr(body.balanceBefore),
        balanceAfter: toStr(body.balanceAfter),
        fees: toStr(body.fees),
        entryReason: toStr(body.entryReason),
        directionReason: toStr(body.directionReason),
        outcomeReason: toStr(body.outcomeReason),
        followedStrategy: toStr(body.followedStrategy),
        followedRules: toStr(body.followedRules),
        mistake: toStr(body.mistake),
        mistakeCustom: toStr(body.mistakeCustom),
        whatDifferently: toStr(body.whatDifferently),
        lessonLearned: toStr(body.lessonLearned),
        nextImprovement: toStr(body.nextImprovement),
        qualityRating: body.qualityRating ? Number(body.qualityRating) : null,
        emotion: toStr(body.emotion),
        followedPlan: toStr(body.followedPlan),
        notes: toStr(body.notes),
      })
      .returning();

    return Response.json({ trade: mapTrade(created, []) }, { status: 201 });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Failed to create trade" }, { status: 500 });
  }
}


