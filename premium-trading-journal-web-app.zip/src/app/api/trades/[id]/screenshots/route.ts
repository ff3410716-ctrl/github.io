import { db } from "@/db";
import { screenshots, trades } from "@/db/schema";
import { mapScreenshot } from "@/lib/db-helpers";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";

export const dynamic = "force-dynamic";

const ALLOWED_TYPES = ["image/png", "image/jpeg", "image/jpg"];

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const tradeId = Number(id);

    const [trade] = await db.select().from(trades).where(eq(trades.id, tradeId));
    if (!trade) return Response.json({ error: "Trade not found" }, { status: 404 });

    const form = await req.formData();
    const files = form.getAll("files") as File[];
    const label = (form.get("label") as string) || "Other";

    if (!files.length) return Response.json({ error: "No files provided" }, { status: 400 });

    const uploadDir = path.join(process.cwd(), "storage", "uploads", "trades", String(tradeId));
    await mkdir(uploadDir, { recursive: true });

    const created = [];
    for (const file of files) {
      if (!ALLOWED_TYPES.includes(file.type)) continue;
      const bytes = Buffer.from(await file.arrayBuffer());
      const ext = file.type === "image/png" ? "png" : "jpg";
      const filename = `${randomUUID()}.${ext}`;
      await writeFile(path.join(uploadDir, filename), bytes);
      const url = `/api/files/trades/${tradeId}/${filename}`;
      const [row] = await db.insert(screenshots).values({ tradeId, url, label }).returning();
      created.push(mapScreenshot(row));
    }

    return Response.json({ screenshots: created }, { status: 201 });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Upload failed" }, { status: 500 });
  }
}
