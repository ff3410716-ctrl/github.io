import { db } from "@/db";
import { trades, screenshots } from "@/db/schema";
import { mapTrade } from "@/lib/db-helpers";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function toStr(v: unknown): string | null {
  if (v === undefined || v === null || v === "") return null;
  return String(v);
}

async function getId(ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  return Number(id);
}

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const id = await getId(ctx);
  const [trade] = await db.select().from(trades).where(eq(trades.id, id));
  if (!trade) return Response.json({ error: "Not found" }, { status: 404 });
  const shots = await db.select().from(screenshots).where(eq(screenshots.tradeId, id));
  return Response.json({ trade: mapTrade(trade, shots) });
}

export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const id = await getId(ctx);
    const body = await req.json();

    const [existing] = await db.select().from(trades).where(eq(trades.id, id));
    if (!existing) return Response.json({ error: "Not found" }, { status: 404 });

    const [updated] = await db
      .update(trades)
      .set({
        tradeDate: body.tradeDate,
        tradeTime: body.tradeTime,
        instrument: body.instrument,
        customInstrument: toStr(body.customInstrument),
        market: body.market,
        direction: body.direction,
        lotSize: toStr(body.lotSize),
        entryPrice: toStr(body.entryPrice),
        stopLoss: toStr(body.stopLoss),
        takeProfit: toStr(body.takeProfit),
        exitPrice: toStr(body.exitPrice),
        pips: toStr(body.pips),
        riskReward: toStr(body.riskReward),
        strategy: toStr(body.strategy),
        session: toStr(body.session),
        result: body.result,
        pnlUsd: toStr(body.pnlUsd),
        balanceBefore: toStr(body.balanceBefore),
        balanceAfter: toStr(body.balanceAfter),
        fees: toStr(body.fees),
        entryReason: toStr(body.entryReason),
        directionReason: toStr(body.directionReason),
        outcomeReason: toStr(body.outcomeReason),
        followedStrategy: toStr(body.followedStrategy),
        followedRules: toStr(body.followedRules),
        mistake: toStr(body.mistake),
        mistakeCustom: toStr(body.mistakeCustom),
        whatDifferently: toStr(body.whatDifferently),
        lessonLearned: toStr(body.lessonLearned),
        nextImprovement: toStr(body.nextImprovement),
        qualityRating: body.qualityRating ? Number(body.qualityRating) : null,
        emotion: toStr(body.emotion),
        followedPlan: toStr(body.followedPlan),
        notes: toStr(body.notes),
        updatedAt: new Date(),
      })
      .where(eq(trades.id, id))
      .returning();

    const shots = await db.select().from(screenshots).where(eq(screenshots.tradeId, id));
    return Response.json({ trade: mapTrade(updated, shots) });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Failed to update trade" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const id = await getId(ctx);
  await db.delete(trades).where(eq(trades.id, id));
  return Response.json({ ok: true });
}
