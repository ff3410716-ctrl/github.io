import { db } from "@/db";
import { appSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

async function ensureSettings() {
  const [row] = await db.select().from(appSettings).where(eq(appSettings.id, 1));
  if (row) return row;
  const [created] = await db.insert(appSettings).values({ id: 1 }).returning();
  return created;
}

function toStr(v: unknown): string | null {
  if (v === undefined || v === null || v === "") return null;
  return String(v);
}

export async function GET() {
  const row = await ensureSettings();
  return Response.json({ settings: row });
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  await ensureSettings();
  const [updated] = await db
    .update(appSettings)
    .set({
      theme: body.theme,
      currency: body.currency,
      timeZone: body.timeZone,
      dateFormat: body.dateFormat,
      defaultInstrument: body.defaultInstrument,
      weeklyTradeLimit: body.weeklyTradeLimit ? Number(body.weeklyTradeLimit) : null,
      dailyMaxLoss: toStr(body.dailyMaxLoss),
      monthlyProfitTarget: toStr(body.monthlyProfitTarget),
      minQualityScore: body.minQualityScore ? Number(body.minQualityScore) : null,
      updatedAt: new Date(),
    })
    .where(eq(appSettings.id, 1))
    .returning();
  return Response.json({ settings: updated });
}
