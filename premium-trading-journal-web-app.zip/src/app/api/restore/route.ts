import { db } from "@/db";
import { trades, screenshots, appSettings, mistakeStatus, dailyReviews } from "@/db/schema";
import { NextRequest } from "next/server";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body || !Array.isArray(body.trades)) {
      return Response.json({ error: "Invalid backup file" }, { status: 400 });
    }

    await db.execute(
      sql`TRUNCATE TABLE ${screenshots}, ${trades}, ${mistakeStatus}, ${dailyReviews} RESTART IDENTITY CASCADE`
    );

    // Preserve original IDs so screenshot -> trade relationships stay intact.
    if (body.trades.length) {
      await db.insert(trades).values(body.trades);
      await db.execute(sql`SELECT setval(pg_get_serial_sequence('trades', 'id'), (SELECT COALESCE(MAX(id), 1) FROM trades))`);
    }
    if (Array.isArray(body.screenshots) && body.screenshots.length) {
      await db.insert(screenshots).values(body.screenshots);
      await db.execute(sql`SELECT setval(pg_get_serial_sequence('screenshots', 'id'), (SELECT COALESCE(MAX(id), 1) FROM screenshots))`);
    }
    if (Array.isArray(body.mistakeStatus) && body.mistakeStatus.length) {
      await db.insert(mistakeStatus).values(body.mistakeStatus);
    }
    if (Array.isArray(body.dailyReviews) && body.dailyReviews.length) {
      await db.insert(dailyReviews).values(body.dailyReviews);
    }
    if (Array.isArray(body.appSettings) && body.appSettings.length) {
      const s = body.appSettings[0];
      await db.insert(appSettings).values(s).onConflictDoUpdate({ target: appSettings.id, set: s });
    }

    return Response.json({ ok: true });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Restore failed" }, { status: 500 });
  }
}
