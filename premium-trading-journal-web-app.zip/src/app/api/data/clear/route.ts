import { db } from "@/db";
import { trades, screenshots, mistakeStatus, dailyReviews } from "@/db/schema";
import { sql } from "drizzle-orm";
import { rm } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    await db.execute(sql`TRUNCATE TABLE ${screenshots}, ${trades}, ${mistakeStatus}, ${dailyReviews} RESTART IDENTITY CASCADE`);
    try {
      await rm(path.join(process.cwd(), "storage", "uploads", "trades"), { recursive: true, force: true });
    } catch {
      // ignore
    }
    return Response.json({ ok: true });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Failed to clear data" }, { status: 500 });
  }
}
