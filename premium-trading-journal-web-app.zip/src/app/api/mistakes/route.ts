import { db } from "@/db";
import { mistakeStatus } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(mistakeStatus);
  return Response.json({ statuses: rows });
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  if (!body.mistake || !body.status) {
    return Response.json({ error: "mistake and status required" }, { status: 400 });
  }
  const [existing] = await db.select().from(mistakeStatus).where(eq(mistakeStatus.mistake, body.mistake));
  if (existing) {
    const [updated] = await db
      .update(mistakeStatus)
      .set({ status: body.status, updatedAt: new Date() })
      .where(eq(mistakeStatus.mistake, body.mistake))
      .returning();
    return Response.json({ status: updated });
  }
  const [created] = await db
    .insert(mistakeStatus)
    .values({ mistake: body.mistake, status: body.status })
    .returning();
  return Response.json({ status: created });
}
