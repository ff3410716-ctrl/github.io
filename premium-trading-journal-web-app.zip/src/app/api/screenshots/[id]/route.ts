import { db } from "@/db";
import { screenshots } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";
import { unlink } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

function storagePathFromUrl(url: string): string | null {
  // url format: /api/files/<segments...>
  const prefix = "/api/files/";
  if (!url.startsWith(prefix)) return null;
  const rel = url.slice(prefix.length);
  return path.join(process.cwd(), "storage", "uploads", rel);
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const shotId = Number(id);
  const [row] = await db.select().from(screenshots).where(eq(screenshots.id, shotId));
  if (row) {
    const filePath = storagePathFromUrl(row.url);
    if (filePath) {
      try {
        await unlink(filePath);
      } catch {
        // file may already be gone, ignore
      }
    }
    await db.delete(screenshots).where(eq(screenshots.id, shotId));
  }
  return Response.json({ ok: true });
}

export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const shotId = Number(id);
  const body = await req.json();
  const [row] = await db
    .update(screenshots)
    .set({ label: body.label })
    .where(eq(screenshots.id, shotId))
    .returning();
  return Response.json({ screenshot: row });
}
