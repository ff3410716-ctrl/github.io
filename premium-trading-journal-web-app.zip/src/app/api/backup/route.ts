import { db } from "@/db";
import { trades, screenshots, appSettings, mistakeStatus, dailyReviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const [t, s, settings, m, d] = await Promise.all([
    db.select().from(trades),
    db.select().from(screenshots),
    db.select().from(appSettings),
    db.select().from(mistakeStatus),
    db.select().from(dailyReviews),
  ]);

  const backup = {
    version: 1,
    exportedAt: new Date().toISOString(),
    trades: t,
    screenshots: s,
    appSettings: settings,
    mistakeStatus: m,
    dailyReviews: d,
  };

  return new Response(JSON.stringify(backup, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="trading-journal-backup-${Date.now()}.json"`,
    },
  });
}
