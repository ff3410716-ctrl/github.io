import { db } from "@/db";
import { dailyReviews } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const date = req.nextUrl.searchParams.get("date");
  if (date) {
    const [row] = await db.select().from(dailyReviews).where(eq(dailyReviews.date, date));
    return Response.json({ review: row ?? null });
  }
  const rows = await db.select().from(dailyReviews).orderBy(desc(dailyReviews.date));
  return Response.json({ reviews: rows });
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  if (!body.date) return Response.json({ error: "date is required" }, { status: 400 });

  const [existing] = await db.select().from(dailyReviews).where(eq(dailyReviews.date, body.date));
  if (existing) {
    const [updated] = await db
      .update(dailyReviews)
      .set({
        followedPlan: body.followedPlan ?? null,
        learned: body.learned ?? null,
        improveTomorrow: body.improveTomorrow ?? null,
        updatedAt: new Date(),
      })
      .where(eq(dailyReviews.date, body.date))
      .returning();
    return Response.json({ review: updated });
  }

  const [created] = await db
    .insert(dailyReviews)
    .values({
      date: body.date,
      followedPlan: body.followedPlan ?? null,
      learned: body.learned ?? null,
      improveTomorrow: body.improveTomorrow ?? null,
    })
    .returning();
  return Response.json({ review: created });
}
