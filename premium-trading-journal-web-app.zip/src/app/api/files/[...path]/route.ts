import { NextRequest } from "next/server";
import { readFile, stat } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

const STORAGE_ROOT = path.join(process.cwd(), "storage", "uploads");

const MIME: Record<string, string> = {
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
};

export async function GET(_req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  try {
    const { path: segments } = await ctx.params;
    const safeSegments = segments.filter((s) => s !== ".." && s !== "." && !s.includes("/"));
    if (safeSegments.length !== segments.length || safeSegments.length === 0) {
      return new Response("Not found", { status: 404 });
    }

    const filePath = path.join(STORAGE_ROOT, ...safeSegments);
    if (!filePath.startsWith(STORAGE_ROOT)) {
      return new Response("Not found", { status: 404 });
    }

    const ext = path.extname(filePath).toLowerCase();
    const mime = MIME[ext];
    if (!mime) return new Response("Not found", { status: 404 });

    await stat(filePath);
    const data = await readFile(filePath);

    return new Response(new Uint8Array(data), {
      headers: {
        "Content-Type": mime,
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
