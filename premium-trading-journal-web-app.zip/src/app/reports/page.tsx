"use client";

import { useMemo, useState } from "react";
import { useAppData } from "@/context/AppDataContext";
import { Card, SectionTitle, Button, StatCard, Spinner, EmptyState } from "@/components/ui/kit";
import { startOfWeek, endOfWeek, startOfMonth, endOfMonth, format } from "date-fns";
import { computeDashboardStats, performanceByKey, filterTradesByRange } from "@/lib/analytics";
import { fmtMoney, fmtPercent } from "@/lib/format";
import { exportTradesCSV, exportReportPDF } from "@/lib/export";
import Link from "next/link";

function mistakeLabel(t: { mistake: string | null; mistakeCustom: string | null }): string | null {
  if (!t.mistake || t.mistake === "None") return null;
  if (t.mistake === "Other") return t.mistakeCustom || "Other";
  return t.mistake;
}

export default function ReportsPage() {
  const { trades, settings, loading } = useAppData();
  const [period, setPeriod] = useState<"week" | "month">("week");
  const currency = settings?.currency || "USD";

  const range = useMemo(() => {
    const now = new Date();
    if (period === "week") return { from: startOfWeek(now, { weekStartsOn: 1 }), to: endOfWeek(now, { weekStartsOn: 1 }) };
    return { from: startOfMonth(now), to: endOfMonth(now) };
  }, [period]);

  const periodTrades = useMemo(() => filterTradesByRange(trades, range.from, range.to), [trades, range]);
  const stats = useMemo(() => computeDashboardStats(periodTrades), [periodTrades]);
  const byInstrument = useMemo(
    () => performanceByKey(periodTrades, (t) => (t.instrument === "Other" ? t.customInstrument || "Other" : t.instrument)),
    [periodTrades]
  );
  const best = byInstrument[0];
  const worst = byInstrument[byInstrument.length - 1];

  const mistakeCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of periodTrades) {
      const m = mistakeLabel(t);
      if (m) map.set(m, (map.get(m) ?? 0) + 1);
    }
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [periodTrades]);

  const topMistake = mistakeCounts[0];

  const improvementAreas = useMemo(
    () =>
      periodTrades
        .map((t) => t.nextImprovement)
        .filter((x): x is string => !!x && x.trim().length > 0)
        .slice(-3),
    [periodTrades]
  );

  function handlePdfExport() {
    exportReportPDF({
      title: period === "week" ? "Weekly Trading Report" : "Monthly Trading Report",
      subtitle: `${format(range.from, "dd MMM yyyy")} - ${format(range.to, "dd MMM yyyy")}`,
      summary: [
        { label: "Total Trades", value: String(stats.totalTrades) },
        { label: "Net P/L", value: fmtMoney(stats.netPnl, currency) },
        { label: "Win Rate", value: fmtPercent(stats.winRate) },
        { label: "Best Instrument", value: best?.key || "—" },
        { label: "Worst Instrument", value: worst?.key || "—" },
        { label: "Most Common Mistake", value: topMistake?.[0] || "None recorded" },
      ],
      trades: periodTrades,
      dateFormat: settings?.dateFormat,
    });
  }

  if (loading) return <Spinner />;

  return (
    <div className="animate-fade-in space-y-5">
      <SectionTitle title="Weekly & Monthly Reports" subtitle="Automatically generated performance summaries, exportable as PDF or CSV." />

      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex gap-2">
            <Button variant={period === "week" ? "primary" : "secondary"} onClick={() => setPeriod("week")}>
              This Week
            </Button>
            <Button variant={period === "month" ? "primary" : "secondary"} onClick={() => setPeriod("month")}>
              This Month
            </Button>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => exportTradesCSV(trades)}>
              Export All CSV
            </Button>
            <Button onClick={handlePdfExport} disabled={periodTrades.length === 0}>
              Export PDF Report
            </Button>
          </div>
        </div>
        <p className="mt-3 text-xs" style={{ color: "var(--text-muted)" }}>
          {format(range.from, "dd MMM yyyy")} – {format(range.to, "dd MMM yyyy")}
        </p>
      </Card>

      {periodTrades.length === 0 ? (
        <EmptyState
          title="No trades in this period"
          message="Record trades during this period to generate a report."
          action={
            <Link href="/trades/new" className="rounded-xl px-4 py-2.5 text-sm font-semibold" style={{ background: "var(--gold)", color: "#15120a" }}>
              + Add Trade
            </Link>
          }
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <StatCard label="Total Trades" value={String(stats.totalTrades)} />
            <StatCard label="Net P/L" value={fmtMoney(stats.netPnl, currency)} tone={stats.netPnl >= 0 ? "profit" : "loss"} />
            <StatCard label="Win Rate" value={fmtPercent(stats.winRate)} tone="gold" />
            <StatCard label="Avg Risk:Reward" value={stats.avgRR ? `1:${stats.avgRR.toFixed(2)}` : "—"} tone="blue" />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Card>
              <SectionTitle title="Best Performing Instrument" />
              <p className="text-xl font-bold" style={{ color: "var(--profit)" }}>
                {best?.key || "—"}
              </p>
              {best && (
                <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
                  {fmtMoney(best.netPnl, currency)} net · {fmtPercent(best.winRate)} win rate
                </p>
              )}
            </Card>
            <Card>
              <SectionTitle title="Worst Performing Instrument" />
              <p className="text-xl font-bold" style={{ color: "var(--loss)" }}>
                {worst?.key || "—"}
              </p>
              {worst && (
                <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
                  {fmtMoney(worst.netPnl, currency)} net · {fmtPercent(worst.winRate)} win rate
                </p>
              )}
            </Card>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Card>
              <SectionTitle title="Most Common Mistake" />
              <p className="text-xl font-bold" style={{ color: "var(--text-primary)" }}>
                {topMistake?.[0] || "None recorded"}
              </p>
              {topMistake && (
                <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
                  {topMistake[1]} occurrence{topMistake[1] !== 1 ? "s" : ""} this period
                </p>
              )}
            </Card>
            <Card>
              <SectionTitle title="Main Improvement Areas" />
              {improvementAreas.length === 0 ? (
                <p className="text-sm" style={{ color: "var(--text-muted)" }}>
                  No improvement notes recorded this period.
                </p>
              ) : (
                <ul className="space-y-1 text-sm" style={{ color: "var(--text-secondary)" }}>
                  {improvementAreas.map((a, i) => (
                    <li key={i}>• {a}</li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
