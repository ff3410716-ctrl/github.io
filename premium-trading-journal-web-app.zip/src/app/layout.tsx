import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppDataProvider } from "@/context/AppDataContext";
import { Shell } from "@/components/Shell";

export const metadata: Metadata = {
  title: "Trading Journal — Premium Edition",
  description: "A premium, AI-ready personal trading journal and analytics platform.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0a0e17",
};

const themeInitScript = `
(function () {
  try {
    var theme = localStorage.getItem("tj-theme") || "dark";
    if (theme === "light") document.documentElement.classList.add("light");
  } catch (e) {}
})();
`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body className="antialiased">
        <AppDataProvider>
          <Shell>{children}</Shell>
        </AppDataProvider>
      </body>
    </html>
  );
}
