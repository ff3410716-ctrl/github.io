"use client";

import { TradeForm } from "@/components/TradeForm";
import { SectionTitle } from "@/components/ui/kit";

export default function NewTradePage() {
  return (
    <div>
      <SectionTitle title="Add New Trade" subtitle="Complete the basics in under a minute — everything else is optional." />
      <TradeForm mode="create" />
    </div>
  );
}
