"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAppData } from "@/context/AppDataContext";
import { Trade } from "@/lib/types";
import {
  Card,
  SectionTitle,
  Badge,
  Button,
  Select,
  Spinner,
  ConfirmDialog,
  PnlText,
} from "@/components/ui/kit";
import { TradeForm } from "@/components/TradeForm";
import { ImageLightbox } from "@/components/ImageLightbox";
import { SCREENSHOT_LABELS } from "@/lib/constants";
import { formatDate, formatTime, dayOfWeek } from "@/lib/timezone";
import { fmtMoney, fmtNum } from "@/lib/format";

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <p className="text-[11px] font-medium uppercase tracking-wide" style={{ color: "var(--text-muted)" }}>
        {label}
      </p>
      <p className="mt-0.5 text-sm font-medium" style={{ color: "var(--text-primary)" }}>
        {value === null || value === undefined || value === "" ? "—" : value}
      </p>
    </div>
  );
}

export default function TradeDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { settings, deleteTrade } = useAppData();
  const [trade, setTrade] = useState<Trade | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [uploadLabel, setUploadLabel] = useState<string>(SCREENSHOT_LABELS[0]);
  const [uploading, setUploading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch(`/api/trades/${params.id}`);
    const data = await res.json();
    if (res.ok) setTrade(data.trade);
    setLoading(false);
  }, [params.id]);

  useEffect(() => {
    load();
  }, [load]);

  async function onUpload(files: FileList | null) {
    if (!files || !trade) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("label", uploadLabel);
    Array.from(files).forEach((f) => fd.append("files", f));
    await fetch(`/api/trades/${trade.id}/screenshots`, { method: "POST", body: fd });
    await load();
    setUploading(false);
  }

  async function onDeleteScreenshot(id: number) {
    await fetch(`/api/screenshots/${id}`, { method: "DELETE" });
    await load();
  }

  async function onRelabel(id: number, label: string) {
    await fetch(`/api/screenshots/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label }),
    });
    await load();
  }

  async function onConfirmDelete() {
    if (!trade) return;
    await deleteTrade(trade.id);
    router.push("/history");
  }

  if (loading) return <Spinner />;
  if (!trade) {
    return (
      <Card>
        <p style={{ color: "var(--text-secondary)" }}>Trade not found.</p>
      </Card>
    );
  }

  const currency = settings?.currency || "USD";

  if (editing) {
    return (
      <div>
        <SectionTitle title="Edit Trade" subtitle="Update any field — your original creation time is preserved." />
        <TradeForm
          mode="edit"
          trade={trade}
          onSaved={(updated) => {
            setTrade(updated);
            setEditing(false);
          }}
          onCancel={() => setEditing(false)}
        />
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-5 pb-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <SectionTitle
          title={`${trade.instrument === "Other" ? trade.customInstrument : trade.instrument} Trade`}
          subtitle={`${formatDate(trade.tradeDate, settings?.dateFormat)} · ${dayOfWeek(trade.tradeDate)} · ${formatTime(trade.tradeTime)}`}
        />
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => setEditing(true)}>
            Edit
          </Button>
          <Button variant="danger" onClick={() => setConfirmDelete(true)}>
            Delete
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Badge tone={trade.direction === "BUY" ? "profit" : "loss"}>{trade.direction}</Badge>
        <Badge tone={trade.result === "PROFIT" ? "profit" : trade.result === "LOSS" ? "loss" : "neutral"}>
          {trade.result.replace("_", " ")}
        </Badge>
        <Badge tone="blue">{trade.market}</Badge>
        {trade.session && <Badge tone="gold">{trade.session} Session</Badge>}
        {trade.followedRules === "No" && <Badge tone="loss">⚠ Rule Violation</Badge>}
        {trade.qualityRating && <Badge tone="neutral">Quality {trade.qualityRating}/10</Badge>}
      </div>

      <Card>
        <SectionTitle title="Trade Overview" />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          <Field label="Lot Size" value={fmtNum(trade.lotSize, 2)} />
          <Field label="Entry Price" value={fmtNum(trade.entryPrice, 5)} />
          <Field label="Stop Loss" value={fmtNum(trade.stopLoss, 5)} />
          <Field label="Take Profit" value={fmtNum(trade.takeProfit, 5)} />
          <Field label="Exit Price" value={fmtNum(trade.exitPrice, 5)} />
          <Field label="Pips" value={trade.pips ?? "—"} />
          <Field label="Risk : Reward" value={trade.riskReward ? `1 : ${trade.riskReward}` : "—"} />
          <Field label="Strategy" value={trade.strategy} />
          <Field label="P/L (USD)" value={<PnlText value={trade.pnlUsd} currency={currency} />} />
          <Field label="Balance Before" value={trade.balanceBefore !== null ? fmtMoney(trade.balanceBefore, currency) : "—"} />
          <Field label="Balance After" value={trade.balanceAfter !== null ? fmtMoney(trade.balanceAfter, currency) : "—"} />
          <Field label="Fees" value={trade.fees !== null ? fmtMoney(trade.fees, currency) : "—"} />
        </div>
      </Card>

      <Card>
        <SectionTitle title="Trade Analysis" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Entry Reason" value={trade.entryReason} />
          <Field label="Direction Reason" value={trade.directionReason} />
          <Field label="Outcome Reason" value={trade.outcomeReason} />
          <Field label="Followed Strategy?" value={trade.followedStrategy} />
          <Field label="Followed Rules?" value={trade.followedRules} />
        </div>
      </Card>

      <Card>
        <SectionTitle title="Mistakes & Lessons" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Mistake" value={trade.mistake === "Other" ? trade.mistakeCustom : trade.mistake} />
          <Field label="What To Do Differently" value={trade.whatDifferently} />
          <Field label="Lesson Learned" value={trade.lessonLearned} />
          <Field label="Next Trade Improvement" value={trade.nextImprovement} />
        </div>
      </Card>

      <Card>
        <SectionTitle title="Psychology" />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <Field label="Emotion Before Entry" value={trade.emotion} />
          <Field label="Followed Trading Plan?" value={trade.followedPlan} />
          <Field label="Quality Rating" value={trade.qualityRating ? `${trade.qualityRating} / 10` : "—"} />
        </div>
      </Card>

      <Card>
        <SectionTitle title="Screenshots" subtitle="Upload, label, or delete trade screenshots." />
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <Select value={uploadLabel} onChange={(e) => setUploadLabel(e.target.value)} className="!w-auto">
            {SCREENSHOT_LABELS.map((l) => (
              <option key={l} value={l}>
                {l}
              </option>
            ))}
          </Select>
          <label
            className="inline-flex cursor-pointer items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold"
            style={{ borderColor: "var(--border-strong)", color: "var(--text-primary)" }}
          >
            {uploading ? "Uploading..." : "+ Upload Images"}
            <input type="file" accept="image/png,image/jpeg,image/jpg" multiple hidden onChange={(e) => onUpload(e.target.files)} />
          </label>
        </div>

        {trade.screenshots.length === 0 ? (
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>
            No screenshots uploaded for this trade yet.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {trade.screenshots.map((s) => (
              <div key={s.id} className="overflow-hidden rounded-xl border" style={{ borderColor: "var(--border)" }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={s.url}
                  alt={s.label}
                  onClick={() => setLightbox(s.url)}
                  className="h-32 w-full cursor-pointer object-cover"
                />
                <div className="flex items-center justify-between gap-1 p-1.5">
                  <select
                    value={s.label}
                    onChange={(e) => onRelabel(s.id, e.target.value)}
                    className="rounded-md border px-1 py-0.5 text-[10px]"
                    style={{ borderColor: "var(--border)", background: "var(--bg-elevated)", color: "var(--text-secondary)" }}
                  >
                    {SCREENSHOT_LABELS.map((l) => (
                      <option key={l} value={l}>
                        {l}
                      </option>
                    ))}
                  </select>
                  <button onClick={() => onDeleteScreenshot(s.id)} className="text-[11px]" style={{ color: "var(--loss)" }}>
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {trade.notes && (
        <Card>
          <SectionTitle title="Notes" />
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            {trade.notes}
          </p>
        </Card>
      )}

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        Created {formatDate(trade.createdAt.slice(0, 10), settings?.dateFormat)} · Last updated {formatDate(trade.updatedAt.slice(0, 10), settings?.dateFormat)}
      </p>

      <ImageLightbox src={lightbox} onClose={() => setLightbox(null)} />
      <ConfirmDialog
        open={confirmDelete}
        title="Delete this trade?"
        message="This will permanently remove the trade and its screenshots. This action cannot be undone."
        confirmLabel="Delete Trade"
        danger
        onConfirm={onConfirmDelete}
        onCancel={() => setConfirmDelete(false)}
      />
    </div>
  );
}
