export type Direction = "BUY" | "SELL";

/** Pip multiplier heuristics per instrument. Returns null when unknown (e.g. "Other"/crypto). */
function pipMultiplier(instrument: string): number | null {
  const sym = instrument.toUpperCase();
  if (sym === "XAUUSD") return 10; // 0.1 move = 1 pip
  if (sym.endsWith("JPY")) return 100; // 0.01 move = 1 pip
  if (sym === "BTCUSD") return null; // priced in points, not pips
  if (["EURUSD", "GBPUSD", "USDJPY"].includes(sym)) return 10000; // 0.0001 move = 1 pip
  if (/^[A-Z]{6}$/.test(sym)) return 10000; // generic forex pair fallback
  return null;
}

export function calcPips(
  instrument: string,
  direction: Direction,
  entry: number | null,
  exit: number | null
): number | null {
  if (entry === null || exit === null || Number.isNaN(entry) || Number.isNaN(exit)) return null;
  const multiplier = pipMultiplier(instrument);
  if (multiplier === null) return null;
  const diff = direction === "BUY" ? exit - entry : entry - exit;
  return Math.round(diff * multiplier * 100) / 100;
}

export function calcRiskReward(
  direction: Direction,
  entry: number | null,
  sl: number | null,
  tp: number | null
): number | null {
  if (entry === null || sl === null || tp === null) return null;
  if (Number.isNaN(entry) || Number.isNaN(sl) || Number.isNaN(tp)) return null;
  const risk = Math.abs(entry - sl);
  const reward = Math.abs(tp - entry);
  if (risk === 0) return null;
  return Math.round((reward / risk) * 100) / 100;
}

export function calcPnlFromBalance(
  before: number | null,
  after: number | null,
  fees: number | null
): number | null {
  if (before === null || after === null || Number.isNaN(before) || Number.isNaN(after)) return null;
  const gross = after - before;
  return Math.round((gross - (fees ?? 0)) * 100) / 100;
}

export function deriveResult(pnl: number | null): "PROFIT" | "LOSS" | "BREAK_EVEN" | null {
  if (pnl === null || Number.isNaN(pnl)) return null;
  if (pnl > 0) return "PROFIT";
  if (pnl < 0) return "LOSS";
  return "BREAK_EVEN";
}

export function resultColor(result: string): string {
  if (result === "PROFIT") return "var(--profit)";
  if (result === "LOSS") return "var(--loss)";
  return "var(--neutral)";
}
