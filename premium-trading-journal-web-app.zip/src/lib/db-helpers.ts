import { TradeRow, ScreenshotRow } from "@/db/schema";
import { Trade, Screenshot } from "./types";

function n(v: string | null): number | null {
  if (v === null || v === undefined) return null;
  const num = Number(v);
  return Number.isNaN(num) ? null : num;
}

export function mapScreenshot(row: ScreenshotRow): Screenshot {
  return {
    id: row.id,
    tradeId: row.tradeId,
    url: row.url,
    label: row.label,
    createdAt: row.createdAt.toISOString(),
  };
}

export function mapTrade(row: TradeRow, screenshots: ScreenshotRow[] = []): Trade {
  return {
    id: row.id,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    tradeDate: row.tradeDate,
    tradeTime: row.tradeTime,
    instrument: row.instrument,
    customInstrument: row.customInstrument,
    market: row.market,
    direction: row.direction as "BUY" | "SELL",
    lotSize: n(row.lotSize),
    entryPrice: n(row.entryPrice),
    stopLoss: n(row.stopLoss),
    takeProfit: n(row.takeProfit),
    exitPrice: n(row.exitPrice),
    pips: n(row.pips),
    riskReward: n(row.riskReward),
    strategy: row.strategy,
    session: row.session,
    result: row.result as "PROFIT" | "LOSS" | "BREAK_EVEN",
    pnlUsd: n(row.pnlUsd),
    balanceBefore: n(row.balanceBefore),
    balanceAfter: n(row.balanceAfter),
    fees: n(row.fees),
    entryReason: row.entryReason,
    directionReason: row.directionReason,
    outcomeReason: row.outcomeReason,
    followedStrategy: row.followedStrategy,
    followedRules: row.followedRules,
    mistake: row.mistake,
    mistakeCustom: row.mistakeCustom,
    whatDifferently: row.whatDifferently,
    lessonLearned: row.lessonLearned,
    nextImprovement: row.nextImprovement,
    qualityRating: row.qualityRating,
    emotion: row.emotion,
    followedPlan: row.followedPlan,
    notes: row.notes,
    screenshots: screenshots.map(mapScreenshot),
  };
}
