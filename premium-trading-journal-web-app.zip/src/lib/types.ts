export type Screenshot = {
  id: number;
  tradeId: number;
  url: string;
  label: string;
  createdAt: string;
};

export type Trade = {
  id: number;
  createdAt: string;
  updatedAt: string;
  tradeDate: string; // yyyy-MM-dd
  tradeTime: string; // HH:mm
  instrument: string;
  customInstrument: string | null;
  market: string;
  direction: "BUY" | "SELL";
  lotSize: number | null;
  entryPrice: number | null;
  stopLoss: number | null;
  takeProfit: number | null;
  exitPrice: number | null;
  pips: number | null;
  riskReward: number | null;
  strategy: string | null;
  session: string | null;
  result: "PROFIT" | "LOSS" | "BREAK_EVEN";
  pnlUsd: number | null;
  balanceBefore: number | null;
  balanceAfter: number | null;
  fees: number | null;
  entryReason: string | null;
  directionReason: string | null;
  outcomeReason: string | null;
  followedStrategy: string | null;
  followedRules: string | null;
  mistake: string | null;
  mistakeCustom: string | null;
  whatDifferently: string | null;
  lessonLearned: string | null;
  nextImprovement: string | null;
  qualityRating: number | null;
  emotion: string | null;
  followedPlan: string | null;
  notes: string | null;
  screenshots: Screenshot[];
};

export type AppSettings = {
  id: number;
  theme: string;
  currency: string;
  timeZone: string;
  dateFormat: string;
  defaultInstrument: string;
  weeklyTradeLimit: number | null;
  dailyMaxLoss: number | null;
  monthlyProfitTarget: number | null;
  minQualityScore: number | null;
};

export type MistakeStatusEntry = {
  mistake: string;
  status: string;
  updatedAt: string;
};

export type DailyReview = {
  date: string;
  followedPlan: string | null;
  learned: string | null;
  improveTomorrow: string | null;
};
