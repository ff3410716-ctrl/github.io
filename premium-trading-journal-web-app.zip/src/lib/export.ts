import { Trade } from "./types";
import { formatDate, formatTime } from "./timezone";

export function downloadBlob(content: BlobPart, filename: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

const CSV_HEADERS = [
  "Date",
  "Day",
  "Time",
  "Instrument",
  "Market",
  "Direction",
  "Lot Size",
  "Entry Price",
  "Stop Loss",
  "Take Profit",
  "Exit Price",
  "Pips",
  "Risk:Reward",
  "Strategy",
  "Session",
  "Result",
  "P/L (USD)",
  "Balance Before",
  "Balance After",
  "Fees",
  "Mistake",
  "Quality Rating",
  "Emotion",
  "Followed Plan",
];

function csvEscape(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function tradesToCSV(trades: Trade[]): string {
  const rows = trades.map((t) => [
    t.tradeDate,
    "", // day computed client side if needed
    t.tradeTime,
    t.instrument === "Other" ? t.customInstrument : t.instrument,
    t.market,
    t.direction,
    t.lotSize,
    t.entryPrice,
    t.stopLoss,
    t.takeProfit,
    t.exitPrice,
    t.pips,
    t.riskReward,
    t.strategy,
    t.session,
    t.result,
    t.pnlUsd,
    t.balanceBefore,
    t.balanceAfter,
    t.fees,
    t.mistake === "Other" ? t.mistakeCustom : t.mistake,
    t.qualityRating,
    t.emotion,
    t.followedPlan,
  ]);
  const lines = [CSV_HEADERS.join(","), ...rows.map((r) => r.map(csvEscape).join(","))];
  return lines.join("\n");
}

export function exportTradesCSV(trades: Trade[]) {
  const csv = tradesToCSV(trades);
  downloadBlob(csv, `trading-journal-${Date.now()}.csv`, "text/csv;charset=utf-8;");
}

export async function exportReportPDF(opts: {
  title: string;
  subtitle: string;
  summary: { label: string; value: string }[];
  trades: Trade[];
  dateFormat?: string;
}) {
  const { jsPDF } = await import("jspdf");
  const autoTableModule = await import("jspdf-autotable");
  const autoTable = autoTableModule.default;

  const doc = new jsPDF();
  doc.setFontSize(18);
  doc.text(opts.title, 14, 18);
  doc.setFontSize(11);
  doc.setTextColor(100);
  doc.text(opts.subtitle, 14, 25);

  autoTable(doc, {
    startY: 32,
    head: [["Metric", "Value"]],
    body: opts.summary.map((s) => [s.label, s.value]),
    styles: { fontSize: 9 },
    headStyles: { fillColor: [20, 25, 41] },
  });

  const afterSummaryY = (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 10;

  autoTable(doc, {
    startY: afterSummaryY,
    head: [["Date", "Time", "Instrument", "Dir", "Entry", "Exit", "P/L", "Result"]],
    body: opts.trades.map((t) => [
      formatDate(t.tradeDate, opts.dateFormat),
      formatTime(t.tradeTime),
      t.instrument === "Other" ? t.customInstrument || "" : t.instrument,
      t.direction,
      t.entryPrice ?? "—",
      t.exitPrice ?? "—",
      t.pnlUsd ?? "—",
      t.result.replace("_", " "),
    ]),
    styles: { fontSize: 8 },
    headStyles: { fillColor: [20, 25, 41] },
  });

  doc.save(`${opts.title.replace(/\s+/g, "-").toLowerCase()}-${Date.now()}.pdf`);
}
