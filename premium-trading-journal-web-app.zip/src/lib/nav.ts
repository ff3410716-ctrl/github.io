export type NavItem = {
  href: string;
  label: string;
  shortLabel?: string;
  icon: string;
};

export const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Dashboard", icon: "LayoutDashboard" },
  { href: "/trades/new", label: "Add Trade", icon: "PlusCircle" },
  { href: "/history", label: "Trade History", shortLabel: "History", icon: "History" },
  { href: "/calendar", label: "Calendar", icon: "Calendar" },
  { href: "/analytics", label: "Analytics", icon: "BarChart3" },
  { href: "/mistakes", label: "Mistake Tracker", shortLabel: "Mistakes", icon: "AlertTriangle" },
  { href: "/daily-review", label: "Daily Review", shortLabel: "Review", icon: "NotebookPen" },
  { href: "/reports", label: "Reports", icon: "FileText" },
  { href: "/settings", label: "Settings", icon: "Settings" },
];

export const MOBILE_NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Home", icon: "LayoutDashboard" },
  { href: "/history", label: "History", icon: "History" },
  { href: "/trades/new", label: "Add", icon: "PlusCircle" },
  { href: "/analytics", label: "Analytics", icon: "BarChart3" },
  { href: "/settings", label: "More", icon: "Menu" },
];
