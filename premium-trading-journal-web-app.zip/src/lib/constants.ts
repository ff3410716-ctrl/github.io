export const INSTRUMENTS = ["XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "BTCUSD", "Other"] as const;

export const MARKETS = ["Forex", "Metals", "Crypto", "Indices", "Other"] as const;

export const DIRECTIONS = ["BUY", "SELL"] as const;

export const SESSIONS = ["Asian", "London", "New York", "Overlap", "Other"] as const;

export const RESULTS = ["PROFIT", "LOSS", "BREAK_EVEN"] as const;

export const RESULT_LABELS: Record<string, string> = {
  PROFIT: "Profit",
  LOSS: "Loss",
  BREAK_EVEN: "Break Even",
};

export const REASON_OPTIONS = [
  "Market Structure",
  "Liquidity Sweep",
  "Break of Structure (BOS)",
  "Change of Character (CHoCH)",
  "Fair Value Gap (FVG)",
  "Order Block",
  "Support / Resistance",
  "News Event",
  "Emotional Trading",
  "Early Entry",
  "Late Entry",
  "Poor Risk Management",
  "Other",
];

export const MISTAKE_OPTIONS = [
  "None",
  "Overtrading",
  "Revenge Trading",
  "FOMO",
  "Early Entry",
  "Late Entry",
  "Moving Stop Loss",
  "Excessive Lot Size",
  "Ignoring Market Structure",
  "Emotional Decisions",
  "Breaking Trading Rules",
  "Other",
];

export const EMOTIONS = [
  "Confident",
  "Calm",
  "Fearful",
  "Greedy",
  "Impatient",
  "Stressed",
  "Emotional",
] as const;

export const YES_NO_PARTIAL = ["Yes", "No", "Partially"] as const;

export const SCREENSHOT_LABELS = ["Before Entry", "During Trade", "After Exit", "Other"] as const;

export const MISTAKE_STATUSES = ["Not Improved", "Improving", "Fixed"] as const;

export const DATE_FILTERS = [
  "Today",
  "This Week",
  "This Month",
  "Last Month",
  "All Time",
  "Custom",
] as const;

export const CURRENCIES = ["USD", "EUR", "GBP", "PKR", "AED", "INR"] as const;

export const DATE_FORMATS = [
  { value: "dd MMMM yyyy", label: "31 October 2026" },
  { value: "MMMM dd, yyyy", label: "October 31, 2026" },
  { value: "dd/MM/yyyy", label: "31/10/2026" },
  { value: "MM/dd/yyyy", label: "10/31/2026" },
  { value: "yyyy-MM-dd", label: "2026-10-31" },
];

export const TIME_ZONES = [
  "Asia/Karachi",
  "UTC",
  "Asia/Dubai",
  "Asia/Kolkata",
  "Europe/London",
  "America/New_York",
];
