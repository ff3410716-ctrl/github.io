import { Trade } from "./types";
import { winRateFor, performanceByKey } from "./analytics";

const MIN_SAMPLE = 3;

export function generateInsights(trades: Trade[]): string[] {
  const insights: string[] = [];
  if (trades.length < 5) return insights;

  // Plan adherence vs win rate
  const followedYes = trades.filter((t) => t.followedPlan === "Yes");
  const followedNo = trades.filter((t) => t.followedPlan === "No");
  if (followedYes.length >= MIN_SAMPLE && followedNo.length >= MIN_SAMPLE) {
    const wrYes = winRateFor(followedYes);
    const wrNo = winRateFor(followedNo);
    if (Math.abs(wrYes - wrNo) >= 5) {
      insights.push(
        wrYes > wrNo
          ? `Your win rate is ${Math.round(wrYes - wrNo)}% higher when you follow your trading plan (${Math.round(wrYes)}% vs ${Math.round(wrNo)}%).`
          : `Surprisingly, your win rate is higher when you deviate from your plan (${Math.round(wrNo)}% vs ${Math.round(wrYes)}%) — review whether your plan needs adjustment.`
      );
    }
  }

  // Session performance
  const bySession = performanceByKey(trades, (t) => t.session || "Unspecified").filter((s) => s.trades >= MIN_SAMPLE);
  if (bySession.length >= 2) {
    const worst = [...bySession].sort((a, b) => a.winRate - b.winRate)[0];
    const best = [...bySession].sort((a, b) => b.winRate - a.winRate)[0];
    if (best.key !== worst.key && best.winRate - worst.winRate >= 15) {
      insights.push(`You have more losing trades during the ${worst.key} session (${Math.round(worst.winRate)}% win rate) compared to ${best.key} (${Math.round(best.winRate)}%).`);
    }
  }

  // Most repeated mistake
  const mistakeCounts = new Map<string, number>();
  for (const t of trades) {
    if (!t.mistake || t.mistake === "None") continue;
    const label = t.mistake === "Other" ? t.mistakeCustom || "Other" : t.mistake;
    mistakeCounts.set(label, (mistakeCounts.get(label) ?? 0) + 1);
  }
  const topMistake = [...mistakeCounts.entries()].sort((a, b) => b[1] - a[1])[0];
  if (topMistake && topMistake[1] >= 2) {
    insights.push(`Your most repeated mistake is "${topMistake[0]}", recorded ${topMistake[1]} times.`);
  }

  // Direction performance
  const byDirection = performanceByKey(trades, (t) => t.direction).filter((d) => d.trades >= MIN_SAMPLE);
  if (byDirection.length === 2) {
    const [a, b] = byDirection;
    if (Math.abs(a.winRate - b.winRate) >= 15) {
      const better = a.winRate > b.winRate ? a : b;
      const worse = a.winRate > b.winRate ? b : a;
      insights.push(`You perform better on ${better.key} trades (${Math.round(better.winRate)}% win rate) than ${worse.key} trades (${Math.round(worse.winRate)}%).`);
    }
  }

  // Emotion performance
  const byEmotion = performanceByKey(trades, (t) => t.emotion || "Unspecified").filter((e) => e.trades >= MIN_SAMPLE);
  if (byEmotion.length >= 2) {
    const worst = [...byEmotion].sort((a, b) => a.winRate - b.winRate)[0];
    if (worst.winRate < 40) {
      insights.push(`When you feel "${worst.key}" before entering a trade, your win rate drops to ${Math.round(worst.winRate)}%.`);
    }
  }

  // Rule-breaking impact
  const brokeRules = trades.filter((t) => t.followedRules === "No");
  const keptRules = trades.filter((t) => t.followedRules === "Yes");
  if (brokeRules.length >= MIN_SAMPLE && keptRules.length >= MIN_SAMPLE) {
    const wrBroke = winRateFor(brokeRules);
    const wrKept = winRateFor(keptRules);
    if (wrKept - wrBroke >= 10) {
      insights.push(`Trades where you broke your own rules have a ${Math.round(wrBroke)}% win rate vs ${Math.round(wrKept)}% when you followed them.`);
    }
  }

  return insights;
}
