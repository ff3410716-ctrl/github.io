import { toZonedTime, format as formatTz } from "date-fns-tz";
import { format as formatPlain, parseISO } from "date-fns";

export const DEFAULT_TZ = "Asia/Karachi";

/** Returns { date: 'yyyy-MM-dd', time: 'HH:mm', day: 'Monday' } for "now" in the given timezone. */
export function getNowParts(timeZone: string = DEFAULT_TZ) {
  const zoned = toZonedTime(new Date(), timeZone);
  return {
    date: formatPlain(zoned, "yyyy-MM-dd"),
    time: formatPlain(zoned, "HH:mm"),
    day: formatPlain(zoned, "EEEE"),
  };
}

/** Day of week name from a yyyy-MM-dd date string, independent of timezone shifting. */
export function dayOfWeek(dateStr: string): string {
  if (!dateStr) return "";
  const d = parseISO(dateStr + "T00:00:00");
  return formatPlain(d, "EEEE");
}

/** Pretty-print a yyyy-MM-dd date using a given date-fns format pattern. */
export function formatDate(dateStr: string, pattern = "dd MMMM yyyy"): string {
  if (!dateStr) return "";
  const d = parseISO(dateStr + "T00:00:00");
  return formatPlain(d, pattern);
}

/** Format a 24h "HH:mm" time string into 12h with AM/PM. */
export function formatTime(timeStr: string): string {
  if (!timeStr) return "";
  const [h, m] = timeStr.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return formatPlain(d, "hh:mm a");
}

export function nowTimestampLabel(timeZone: string = DEFAULT_TZ): string {
  const zoned = toZonedTime(new Date(), timeZone);
  return formatTz(zoned, "dd MMMM yyyy, EEEE, hh:mm a", { timeZone });
}
