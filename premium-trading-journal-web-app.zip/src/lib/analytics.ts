import { Trade } from "./types";
import {
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
  subMonths,
  isWithinInterval,
  parseISO,
  format,
} from "date-fns";

export type DateFilterKey = "Today" | "This Week" | "This Month" | "Last Month" | "All Time" | "Custom";

export function tradeDateObj(t: Trade): Date {
  return parseISO(`${t.tradeDate}T${t.tradeTime || "00:00"}:00`);
}

export function filterTradesByRange(trades: Trade[], from?: Date, to?: Date): Trade[] {
  if (!from || !to) return trades;
  return trades.filter((t) => {
    const d = parseISO(t.tradeDate + "T00:00:00");
    return isWithinInterval(d, { start: from, end: to });
  });
}

export function rangeForFilter(filter: DateFilterKey, custom?: { from: string; to: string }) {
  const now = new Date();
  switch (filter) {
    case "Today": {
      const start = new Date(now);
      start.setHours(0, 0, 0, 0);
      const end = new Date(now);
      end.setHours(23, 59, 59, 999);
      return { from: start, to: end };
    }
    case "This Week":
      return { from: startOfWeek(now, { weekStartsOn: 1 }), to: endOfWeek(now, { weekStartsOn: 1 }) };
    case "This Month":
      return { from: startOfMonth(now), to: endOfMonth(now) };
    case "Last Month": {
      const lastMonth = subMonths(now, 1);
      return { from: startOfMonth(lastMonth), to: endOfMonth(lastMonth) };
    }
    case "Custom":
      if (custom?.from && custom?.to) {
        const f = parseISO(custom.from + "T00:00:00");
        const t = parseISO(custom.to + "T23:59:59");
        return { from: f, to: t };
      }
      return { from: undefined, to: undefined };
    case "All Time":
    default:
      return { from: undefined, to: undefined };
  }
}

export type DashboardStats = {
  totalTrades: number;
  totalProfit: number;
  totalLoss: number;
  netPnl: number;
  winningTrades: number;
  losingTrades: number;
  breakEvenTrades: number;
  winRate: number;
  avgProfit: number;
  avgLoss: number;
  largestWin: number;
  largestLoss: number;
  avgRR: number;
};

export function computeDashboardStats(trades: Trade[]): DashboardStats {
  const wins = trades.filter((t) => t.result === "PROFIT");
  const losses = trades.filter((t) => t.result === "LOSS");
  const breakEven = trades.filter((t) => t.result === "BREAK_EVEN");

  const totalProfit = wins.reduce((s, t) => s + (t.pnlUsd ?? 0), 0);
  const totalLoss = losses.reduce((s, t) => s + Math.abs(t.pnlUsd ?? 0), 0);
  const netPnl = trades.reduce((s, t) => s + (t.pnlUsd ?? 0), 0);

  const rrValues = trades.filter((t) => t.riskReward != null).map((t) => t.riskReward as number);

  return {
    totalTrades: trades.length,
    totalProfit,
    totalLoss,
    netPnl,
    winningTrades: wins.length,
    losingTrades: losses.length,
    breakEvenTrades: breakEven.length,
    winRate: trades.length ? (wins.length / trades.length) * 100 : 0,
    avgProfit: wins.length ? totalProfit / wins.length : 0,
    avgLoss: losses.length ? totalLoss / losses.length : 0,
    largestWin: wins.length ? Math.max(...wins.map((t) => t.pnlUsd ?? 0)) : 0,
    largestLoss: losses.length ? Math.min(...losses.map((t) => t.pnlUsd ?? 0)) : 0,
    avgRR: rrValues.length ? rrValues.reduce((a, b) => a + b, 0) / rrValues.length : 0,
  };
}

export function equityCurve(trades: Trade[]): { label: string; value: number }[] {
  const sorted = [...trades].sort((a, b) => tradeDateObj(a).getTime() - tradeDateObj(b).getTime());
  let cumulative = 0;
  return sorted.map((t) => {
    cumulative += t.pnlUsd ?? 0;
    return { label: format(tradeDateObj(t), "dd MMM"), value: Math.round(cumulative * 100) / 100 };
  });
}

export function groupPnlByDay(trades: Trade[]): { label: string; pnl: number }[] {
  const sorted = [...trades].sort((a, b) => tradeDateObj(a).getTime() - tradeDateObj(b).getTime());
  const map = new Map<string, number>();
  for (const t of sorted) {
    const key = t.tradeDate;
    map.set(key, (map.get(key) ?? 0) + (t.pnlUsd ?? 0));
  }
  return Array.from(map.entries()).map(([date, pnl]) => ({
    label: format(parseISO(date + "T00:00:00"), "dd MMM"),
    pnl: Math.round(pnl * 100) / 100,
  }));
}

export function groupBy<T, K extends string>(trades: T[], keyFn: (t: T) => K): Record<K, T[]> {
  const result = {} as Record<K, T[]>;
  for (const t of trades) {
    const k = keyFn(t);
    if (!result[k]) result[k] = [];
    result[k].push(t);
  }
  return result;
}

export function winRateFor(trades: Trade[]) {
  const decisive = trades.filter((t) => t.result !== "BREAK_EVEN");
  const wins = trades.filter((t) => t.result === "PROFIT");
  return decisive.length ? (wins.length / decisive.length) * 100 : 0;
}

export function netPnlFor(trades: Trade[]) {
  return trades.reduce((s, t) => s + (t.pnlUsd ?? 0), 0);
}

export function consecutiveStreaks(trades: Trade[]) {
  const sorted = [...trades].sort((a, b) => tradeDateObj(a).getTime() - tradeDateObj(b).getTime());
  let maxWinStreak = 0;
  let maxLossStreak = 0;
  let curWin = 0;
  let curLoss = 0;
  for (const t of sorted) {
    if (t.result === "PROFIT") {
      curWin += 1;
      curLoss = 0;
    } else if (t.result === "LOSS") {
      curLoss += 1;
      curWin = 0;
    } else {
      curWin = 0;
      curLoss = 0;
    }
    maxWinStreak = Math.max(maxWinStreak, curWin);
    maxLossStreak = Math.max(maxLossStreak, curLoss);
  }
  return { maxWinStreak, maxLossStreak };
}

export function maxDrawdown(trades: Trade[]): number {
  const withBalance = trades.filter((t) => t.balanceAfter != null);
  const sorted = [...withBalance].sort((a, b) => tradeDateObj(a).getTime() - tradeDateObj(b).getTime());
  if (sorted.length < 2) return 0;
  let peak = sorted[0].balanceAfter as number;
  let maxDd = 0;
  for (const t of sorted) {
    const bal = t.balanceAfter as number;
    if (bal > peak) peak = bal;
    const dd = peak > 0 ? ((peak - bal) / peak) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
  }
  return Math.round(maxDd * 100) / 100;
}

export function dailyNetMap(trades: Trade[]): Map<string, { pnl: number; count: number }> {
  const map = new Map<string, { pnl: number; count: number }>();
  for (const t of trades) {
    const cur = map.get(t.tradeDate) ?? { pnl: 0, count: 0 };
    cur.pnl += t.pnlUsd ?? 0;
    cur.count += 1;
    map.set(t.tradeDate, cur);
  }
  return map;
}

export function dayColor(pnl: number, count: number): "profit" | "loss" | "neutral" | "none" {
  if (count === 0) return "none";
  if (pnl > 0) return "profit";
  if (pnl < 0) return "loss";
  return "neutral";
}

export type KeyPerformance = {
  key: string;
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  netPnl: number;
};

export function performanceByKey(trades: Trade[], keyFn: (t: Trade) => string): KeyPerformance[] {
  const groups = groupBy(trades, keyFn as (t: Trade) => string);
  return Object.entries(groups)
    .map(([key, list]) => {
      const wins = list.filter((t) => t.result === "PROFIT").length;
      const losses = list.filter((t) => t.result === "LOSS").length;
      const decisive = list.filter((t) => t.result !== "BREAK_EVEN").length;
      return {
        key,
        trades: list.length,
        wins,
        losses,
        winRate: decisive ? (wins / decisive) * 100 : 0,
        netPnl: netPnlFor(list),
      };
    })
    .sort((a, b) => b.netPnl - a.netPnl);
}

export function groupByWeekLabel(trades: Trade[]): { label: string; pnl: number }[] {
  const sorted = [...trades].sort((a, b) => tradeDateObj(a).getTime() - tradeDateObj(b).getTime());
  const map = new Map<string, number>();
  for (const t of sorted) {
    const d = tradeDateObj(t);
    const weekStart = startOfWeek(d, { weekStartsOn: 1 });
    const key = format(weekStart, "dd MMM");
    map.set(key, (map.get(key) ?? 0) + (t.pnlUsd ?? 0));
  }
  return Array.from(map.entries()).map(([label, pnl]) => ({ label, pnl: Math.round(pnl * 100) / 100 }));
}

export function groupByMonthLabel(trades: Trade[]): { label: string; pnl: number }[] {
  const sorted = [...trades].sort((a, b) => tradeDateObj(a).getTime() - tradeDateObj(b).getTime());
  const map = new Map<string, number>();
  for (const t of sorted) {
    const key = format(tradeDateObj(t), "MMM yyyy");
    map.set(key, (map.get(key) ?? 0) + (t.pnlUsd ?? 0));
  }
  return Array.from(map.entries()).map(([label, pnl]) => ({ label, pnl: Math.round(pnl * 100) / 100 }));
}
