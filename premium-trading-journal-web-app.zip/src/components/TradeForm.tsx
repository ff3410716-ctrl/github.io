"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useAppData } from "@/context/AppDataContext";
import {
  INSTRUMENTS,
  MARKETS,
  SESSIONS,
  REASON_OPTIONS,
  MISTAKE_OPTIONS,
  EMOTIONS,
  YES_NO_PARTIAL,
  SCREENSHOT_LABELS,
} from "@/lib/constants";
import { calcPips, calcRiskReward, calcPnlFromBalance, deriveResult } from "@/lib/calculations";
import { getNowParts, dayOfWeek, formatDate } from "@/lib/timezone";
import { Card, SectionTitle, Label, Input, Select, TextArea, Button, Badge } from "@/components/ui/kit";
import { Trade } from "@/lib/types";
import Image from "next/image";

type Props = {
  mode: "create" | "edit";
  trade?: Trade;
  onSaved?: (trade: Trade) => void;
  onCancel?: () => void;
};

type PendingFile = { file: File; previewUrl: string; label: string };

export function TradeForm({ mode, trade, onSaved, onCancel }: Props) {
  const router = useRouter();
  const { createTrade, updateTrade, settings } = useAppData();
  const now = useMemo(() => getNowParts(settings?.timeZone || "Asia/Karachi"), [settings?.timeZone]);

  const [form, setForm] = useState(() => ({
    tradeDate: trade?.tradeDate || now.date,
    tradeTime: trade?.tradeTime || now.time,
    instrument: trade?.instrument || settings?.defaultInstrument || "XAUUSD",
    customInstrument: trade?.customInstrument || "",
    market: trade?.market || "Metals",
    direction: trade?.direction || "BUY",
    lotSize: trade?.lotSize?.toString() ?? "",
    entryPrice: trade?.entryPrice?.toString() ?? "",
    stopLoss: trade?.stopLoss?.toString() ?? "",
    takeProfit: trade?.takeProfit?.toString() ?? "",
    exitPrice: trade?.exitPrice?.toString() ?? "",
    strategy: trade?.strategy || "",
    session: trade?.session || "London",
    result: trade?.result || "PROFIT",
    pnlUsd: trade?.pnlUsd?.toString() ?? "",
    balanceBefore: trade?.balanceBefore?.toString() ?? "",
    balanceAfter: trade?.balanceAfter?.toString() ?? "",
    fees: trade?.fees?.toString() ?? "",
    entryReason: trade?.entryReason || "",
    entryReasonCustom: "",
    directionReason: trade?.directionReason || "",
    directionReasonCustom: "",
    outcomeReason: trade?.outcomeReason || "",
    outcomeReasonCustom: "",
    followedStrategy: trade?.followedStrategy || "Yes",
    followedRules: trade?.followedRules || "Yes",
    mistake: trade?.mistake || "None",
    mistakeCustom: trade?.mistakeCustom || "",
    whatDifferently: trade?.whatDifferently || "",
    lessonLearned: trade?.lessonLearned || "",
    nextImprovement: trade?.nextImprovement || "",
    qualityRating: trade?.qualityRating?.toString() ?? "7",
    emotion: trade?.emotion || "Calm",
    followedPlan: trade?.followedPlan || "Yes",
    notes: trade?.notes || "",
  }));

  const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
  const [uploadLabel, setUploadLabel] = useState<string>(SCREENSHOT_LABELS[0]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  // Live calculations
  const computedPips = useMemo(() => {
    const entry = form.entryPrice ? Number(form.entryPrice) : null;
    const exit = form.exitPrice ? Number(form.exitPrice) : null;
    return calcPips(form.instrument, form.direction as "BUY" | "SELL", entry, exit);
  }, [form.instrument, form.direction, form.entryPrice, form.exitPrice]);

  const computedRR = useMemo(() => {
    const entry = form.entryPrice ? Number(form.entryPrice) : null;
    const sl = form.stopLoss ? Number(form.stopLoss) : null;
    const tp = form.takeProfit ? Number(form.takeProfit) : null;
    return calcRiskReward(form.direction as "BUY" | "SELL", entry, sl, tp);
  }, [form.direction, form.entryPrice, form.stopLoss, form.takeProfit]);

  const computedPnlFromBalance = useMemo(() => {
    const before = form.balanceBefore ? Number(form.balanceBefore) : null;
    const after = form.balanceAfter ? Number(form.balanceAfter) : null;
    const fees = form.fees ? Number(form.fees) : 0;
    return calcPnlFromBalance(before, after, fees);
  }, [form.balanceBefore, form.balanceAfter, form.fees]);

  // Auto-suggest result based on P/L if user hasn't manually touched result after pnl changes materially
  useEffect(() => {
    const pnl = form.pnlUsd ? Number(form.pnlUsd) : computedPnlFromBalance;
    const derived = deriveResult(pnl);
    if (derived && !form.pnlUsd && computedPnlFromBalance !== null) {
      set("pnlUsd", String(computedPnlFromBalance));
      set("result", derived);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [computedPnlFromBalance]);

  function onFilesSelected(fileList: FileList | null) {
    if (!fileList) return;
    const arr = Array.from(fileList).filter((f) => ["image/png", "image/jpeg", "image/jpg"].includes(f.type));
    const mapped = arr.map((file) => ({ file, previewUrl: URL.createObjectURL(file), label: uploadLabel }));
    setPendingFiles((prev) => [...prev, ...mapped]);
  }

  function removePendingFile(idx: number) {
    setPendingFiles((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (form.instrument === "Other" && !form.customInstrument.trim()) {
      setError("Please specify the custom instrument name.");
      return;
    }
    if (!form.entryPrice) {
      setError("Entry price is required.");
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        tradeDate: form.tradeDate,
        tradeTime: form.tradeTime,
        instrument: form.instrument,
        customInstrument: form.instrument === "Other" ? form.customInstrument : null,
        market: form.market,
        direction: form.direction,
        lotSize: form.lotSize || null,
        entryPrice: form.entryPrice || null,
        stopLoss: form.stopLoss || null,
        takeProfit: form.takeProfit || null,
        exitPrice: form.exitPrice || null,
        pips: computedPips,
        riskReward: computedRR,
        strategy: form.strategy || null,
        session: form.session,
        result: form.result,
        pnlUsd: form.pnlUsd || (computedPnlFromBalance ?? null),
        balanceBefore: form.balanceBefore || null,
        balanceAfter: form.balanceAfter || null,
        fees: form.fees || null,
        entryReason: form.entryReason === "Other" ? form.entryReasonCustom : form.entryReason,
        directionReason: form.directionReason === "Other" ? form.directionReasonCustom : form.directionReason,
        outcomeReason: form.outcomeReason === "Other" ? form.outcomeReasonCustom : form.outcomeReason,
        followedStrategy: form.followedStrategy,
        followedRules: form.followedRules,
        mistake: form.mistake,
        mistakeCustom: form.mistake === "Other" ? form.mistakeCustom : null,
        whatDifferently: form.whatDifferently || null,
        lessonLearned: form.lessonLearned || null,
        nextImprovement: form.nextImprovement || null,
        qualityRating: form.qualityRating || null,
        emotion: form.emotion,
        followedPlan: form.followedPlan,
        notes: form.notes || null,
      };

      let savedId: number;
      let savedTrade: Trade;
      if (mode === "create") {
        savedTrade = await createTrade(payload);
        savedId = savedTrade.id;
      } else if (trade) {
        savedTrade = await updateTrade(trade.id, payload);
        savedId = trade.id;
      } else {
        throw new Error("Missing trade to edit");
      }

      if (pendingFiles.length) {
        const byLabel = new Map<string, File[]>();
        for (const pf of pendingFiles) {
          const list = byLabel.get(pf.label) ?? [];
          list.push(pf.file);
          byLabel.set(pf.label, list);
        }
        for (const [label, files] of byLabel.entries()) {
          const fd = new FormData();
          fd.append("label", label);
          files.forEach((f) => fd.append("files", f));
          await fetch(`/api/trades/${savedId}/screenshots`, { method: "POST", body: fd });
        }
      }

      if (mode === "create") {
        setSuccessMsg("Trade saved successfully!");
        setTimeout(() => router.push(`/trades/${savedId}`), 600);
      } else if (onSaved) {
        onSaved(savedTrade!);
      } else {
        router.push(`/trades/${trade?.id}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="animate-fade-in space-y-5 pb-10">
      {error && (
        <div className="rounded-xl border px-4 py-3 text-sm" style={{ borderColor: "var(--loss)", color: "var(--loss)", background: "var(--loss-soft)" }}>
          {error}
        </div>
      )}
      {successMsg && (
        <div className="rounded-xl border px-4 py-3 text-sm" style={{ borderColor: "var(--profit)", color: "var(--profit)", background: "var(--profit-soft)" }}>
          {successMsg}
        </div>
      )}

      {/* A. Basic Trade Information */}
      <Card>
        <SectionTitle title="Basic Trade Information" subtitle="Date & time are captured automatically but editable for back-dated entries." />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <div>
            <Label required>Trade Date</Label>
            <Input type="date" value={form.tradeDate} onChange={(e) => set("tradeDate", e.target.value)} required />
          </div>
          <div>
            <Label>Day</Label>
            <Input value={dayOfWeek(form.tradeDate)} disabled readOnly />
          </div>
          <div>
            <Label required>Trade Time</Label>
            <Input type="time" value={form.tradeTime} onChange={(e) => set("tradeTime", e.target.value)} required />
          </div>
          <div>
            <Label>Formatted Date</Label>
            <Input value={formatDate(form.tradeDate, settings?.dateFormat)} disabled readOnly />
          </div>

          <div>
            <Label required>Trading Instrument</Label>
            <Select value={form.instrument} onChange={(e) => set("instrument", e.target.value)}>
              {INSTRUMENTS.map((i) => (
                <option key={i} value={i}>
                  {i}
                </option>
              ))}
            </Select>
          </div>
          {form.instrument === "Other" && (
            <div>
              <Label required>Custom Instrument</Label>
              <Input value={form.customInstrument} onChange={(e) => set("customInstrument", e.target.value)} placeholder="e.g. US30" />
            </div>
          )}
          <div>
            <Label required>Trading Market</Label>
            <Select value={form.market} onChange={(e) => set("market", e.target.value)}>
              {MARKETS.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label required>Trading Session</Label>
            <Select value={form.session} onChange={(e) => set("session", e.target.value)}>
              {SESSIONS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </div>
        </div>
      </Card>

      {/* B. Direction */}
      <Card>
        <SectionTitle title="Trade Direction" subtitle="Which position did you take?" />
        <div className="flex gap-3">
          {(["BUY", "SELL"] as const).map((d) => (
            <button
              type="button"
              key={d}
              onClick={() => set("direction", d)}
              className="flex-1 rounded-xl border px-4 py-3 text-sm font-bold transition"
              style={{
                borderColor: form.direction === d ? (d === "BUY" ? "var(--profit)" : "var(--loss)") : "var(--border)",
                background: form.direction === d ? (d === "BUY" ? "var(--profit-soft)" : "var(--loss-soft)") : "transparent",
                color: d === "BUY" ? "var(--profit)" : "var(--loss)",
              }}
            >
              {d}
            </button>
          ))}
        </div>
      </Card>

      {/* C. Lot size & details */}
      <Card>
        <SectionTitle title="Lot Size & Trade Details" subtitle="All values support decimals." />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <div>
            <Label>Lot Size</Label>
            <Input type="number" step="any" value={form.lotSize} onChange={(e) => set("lotSize", e.target.value)} placeholder="0.10" />
          </div>
          <div>
            <Label required>Entry Price</Label>
            <Input type="number" step="any" value={form.entryPrice} onChange={(e) => set("entryPrice", e.target.value)} placeholder="2385.50" required />
          </div>
          <div>
            <Label>Stop Loss</Label>
            <Input type="number" step="any" value={form.stopLoss} onChange={(e) => set("stopLoss", e.target.value)} placeholder="2380.00" />
          </div>
          <div>
            <Label>Take Profit</Label>
            <Input type="number" step="any" value={form.takeProfit} onChange={(e) => set("takeProfit", e.target.value)} placeholder="2395.00" />
          </div>
          <div>
            <Label>Exit Price</Label>
            <Input type="number" step="any" value={form.exitPrice} onChange={(e) => set("exitPrice", e.target.value)} placeholder="2392.30" />
          </div>
          <div>
            <Label>Pips (auto)</Label>
            <Input value={computedPips ?? "—"} disabled readOnly />
          </div>
          <div>
            <Label>Risk : Reward (auto)</Label>
            <Input value={computedRR ? `1 : ${computedRR}` : "—"} disabled readOnly />
          </div>
          <div>
            <Label>Trading Strategy</Label>
            <Input value={form.strategy} onChange={(e) => set("strategy", e.target.value)} placeholder="e.g. Breakout, ICT, Supply/Demand" />
          </div>
        </div>
      </Card>

      {/* D. Result */}
      <Card>
        <SectionTitle title="Trade Result" subtitle="What was the result of this trade?" />
        <div className="grid grid-cols-3 gap-3">
          {(
            [
              { k: "PROFIT", tone: "profit" },
              { k: "LOSS", tone: "loss" },
              { k: "BREAK_EVEN", tone: "neutral" },
            ] as const
          ).map((r) => (
            <button
              type="button"
              key={r.k}
              onClick={() => set("result", r.k)}
              className="rounded-xl border px-3 py-3 text-xs font-bold tracking-wide transition sm:text-sm"
              style={{
                borderColor: form.result === r.k ? `var(--${r.tone})` : "var(--border)",
                background: form.result === r.k ? `var(--${r.tone}-soft)` : "transparent",
                color: `var(--${r.tone})`,
              }}
            >
              {r.k.replace("_", " ")}
            </button>
          ))}
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          <div>
            <Label>Profit / Loss (USD)</Label>
            <Input type="number" step="any" value={form.pnlUsd} onChange={(e) => set("pnlUsd", e.target.value)} placeholder="Enter manually if needed" />
          </div>
          <div>
            <Label>Balance Before (optional)</Label>
            <Input type="number" step="any" value={form.balanceBefore} onChange={(e) => set("balanceBefore", e.target.value)} />
          </div>
          <div>
            <Label>Balance After (optional)</Label>
            <Input type="number" step="any" value={form.balanceAfter} onChange={(e) => set("balanceAfter", e.target.value)} />
          </div>
          <div>
            <Label>Fees / Commission / Swap (optional)</Label>
            <Input type="number" step="any" value={form.fees} onChange={(e) => set("fees", e.target.value)} />
          </div>
        </div>
        {computedPnlFromBalance !== null && !form.pnlUsd && (
          <p className="mt-2 text-xs" style={{ color: "var(--text-muted)" }}>
            Auto-calculated P/L from balance: <strong>{computedPnlFromBalance}</strong>
          </p>
        )}
      </Card>

      {/* E. Trade Analysis */}
      <Card>
        <SectionTitle title="Trade Analysis" subtitle="Understand your own decision making." />
        <div className="grid gap-4 md:grid-cols-2">
          <ReasonField
            label="Why did you enter this trade?"
            value={form.entryReason}
            onChange={(v) => set("entryReason", v)}
            custom={form.entryReasonCustom}
            onCustomChange={(v) => set("entryReasonCustom", v)}
          />
          <ReasonField
            label="Reason behind your BUY/SELL decision?"
            value={form.directionReason}
            onChange={(v) => set("directionReason", v)}
            custom={form.directionReasonCustom}
            onCustomChange={(v) => set("directionReasonCustom", v)}
          />
          <ReasonField
            label="Main reason for your profit or loss?"
            value={form.outcomeReason}
            onChange={(v) => set("outcomeReason", v)}
            custom={form.outcomeReasonCustom}
            onCustomChange={(v) => set("outcomeReasonCustom", v)}
          />
          <div>
            <Label>Did you follow your trading strategy?</Label>
            <Select value={form.followedStrategy} onChange={(e) => set("followedStrategy", e.target.value)}>
              {YES_NO_PARTIAL.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Did you follow your trading rules?</Label>
            <Select value={form.followedRules} onChange={(e) => set("followedRules", e.target.value)}>
              {YES_NO_PARTIAL.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </Select>
            {form.followedRules === "No" && (
              <p className="mt-1.5 text-xs font-medium" style={{ color: "var(--loss)" }}>
                ⚠ Rule violation recorded — review this trade carefully.
              </p>
            )}
          </div>
        </div>
      </Card>

      {/* F. Mistakes & Lessons */}
      <Card>
        <SectionTitle title="Mistakes & Lessons Learned" subtitle="Turn every mistake into a practical rule." />
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <Label>What mistake did you make?</Label>
            <Select value={form.mistake} onChange={(e) => set("mistake", e.target.value)}>
              {MISTAKE_OPTIONS.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </Select>
            {form.mistake === "Other" && (
              <Input className="mt-2" value={form.mistakeCustom} onChange={(e) => set("mistakeCustom", e.target.value)} placeholder="Describe the mistake" />
            )}
          </div>
          <div>
            <Label>What should you have done differently?</Label>
            <TextArea rows={2} value={form.whatDifferently} onChange={(e) => set("whatDifferently", e.target.value)} />
          </div>
          <div>
            <Label>What lesson did you learn?</Label>
            <TextArea rows={2} value={form.lessonLearned} onChange={(e) => set("lessonLearned", e.target.value)} />
          </div>
          <div>
            <Label>My Next Trade Improvement</Label>
            <TextArea rows={2} value={form.nextImprovement} onChange={(e) => set("nextImprovement", e.target.value)} placeholder="One practical rule for next time" />
          </div>
        </div>
      </Card>

      {/* Psychology */}
      <Card>
        <SectionTitle title="Trading Psychology" subtitle="Track emotional patterns behind your trades." />
        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <Label>How were you feeling before entering?</Label>
            <Select value={form.emotion} onChange={(e) => set("emotion", e.target.value)}>
              {EMOTIONS.map((e2) => (
                <option key={e2} value={e2}>
                  {e2}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Did you follow your trading plan?</Label>
            <Select value={form.followedPlan} onChange={(e) => set("followedPlan", e.target.value)}>
              {YES_NO_PARTIAL.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Trade Quality Rating (1–10)</Label>
            <Input type="number" min={1} max={10} value={form.qualityRating} onChange={(e) => set("qualityRating", e.target.value)} />
          </div>
        </div>
      </Card>

      {/* Screenshots */}
      <Card>
        <SectionTitle title="Screenshot Upload" subtitle="PNG, JPG and JPEG supported. Label each screenshot for clarity." />
        <div className="flex flex-wrap items-center gap-3">
          <Select value={uploadLabel} onChange={(e) => setUploadLabel(e.target.value)} className="!w-auto">
            {SCREENSHOT_LABELS.map((l) => (
              <option key={l} value={l}>
                {l}
              </option>
            ))}
          </Select>
          <label
            className="inline-flex cursor-pointer items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold"
            style={{ borderColor: "var(--border-strong)", color: "var(--text-primary)" }}
          >
            + Upload Images
            <input type="file" accept="image/png,image/jpeg,image/jpg" multiple hidden onChange={(e) => onFilesSelected(e.target.files)} />
          </label>
        </div>

        {(pendingFiles.length > 0 || (trade?.screenshots?.length ?? 0) > 0) && (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {trade?.screenshots?.map((s) => (
              <div key={s.id} className="relative overflow-hidden rounded-xl border" style={{ borderColor: "var(--border)" }}>
                <a href={s.url} target="_blank" rel="noreferrer">
                  <Image src={s.url} alt={s.label} width={200} height={140} className="h-28 w-full object-cover" unoptimized />
                </a>
                <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 text-[10px] text-white">{s.label}</span>
              </div>
            ))}
            {pendingFiles.map((pf, idx) => (
              <div key={idx} className="relative overflow-hidden rounded-xl border" style={{ borderColor: "var(--border)" }}>
                <Image src={pf.previewUrl} alt="preview" width={200} height={140} className="h-28 w-full object-cover" unoptimized />
                <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 text-[10px] text-white">{pf.label}</span>
                <button
                  type="button"
                  onClick={() => removePendingFile(idx)}
                  className="absolute right-1 top-1 rounded-full bg-black/70 px-1.5 py-0.5 text-[10px] text-white"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}
        {trade && (
          <p className="mt-2 text-xs" style={{ color: "var(--text-muted)" }}>
            Manage existing screenshots from the trade detail page after saving.
          </p>
        )}
      </Card>

      <div className="flex items-center justify-end gap-3">
        <Badge tone="gold">Record once — analyze anytime</Badge>
        {onCancel && (
          <Button type="button" variant="secondary" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" disabled={submitting}>
          {submitting ? "Saving..." : mode === "create" ? "Save Trade" : "Update Trade"}
        </Button>
      </div>
    </form>
  );
}

function ReasonField({
  label,
  value,
  onChange,
  custom,
  onCustomChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  custom: string;
  onCustomChange: (v: string) => void;
}) {
  return (
    <div>
      <Label>{label}</Label>
      <Select value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">Select a reason...</option>
        {REASON_OPTIONS.map((r) => (
          <option key={r} value={r}>
            {r}
          </option>
        ))}
      </Select>
      {value === "Other" && (
        <Input className="mt-2" value={custom} onChange={(e) => onCustomChange(e.target.value)} placeholder="Describe your reason" />
      )}
    </div>
  );
}
