"use client";

import { ReactNode, InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes, useEffect } from "react";
import clsx from "clsx";

export function Card({
  children,
  className,
  hover,
}: {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}) {
  return (
    <div
      className={clsx(
        "rounded-2xl border p-5",
        className
      )}
      style={{
        background: "var(--card)",
        borderColor: "var(--border)",
        boxShadow: "var(--shadow)",
        transition: "background-color .15s ease, border-color .15s ease",
      }}
      onMouseEnter={(e) => {
        if (hover) (e.currentTarget as HTMLDivElement).style.background = "var(--card-hover)";
      }}
      onMouseLeave={(e) => {
        if (hover) (e.currentTarget as HTMLDivElement).style.background = "var(--card)";
      }}
    >
      {children}
    </div>
  );
}

export function SectionTitle({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
      <div>
        <h2 className="text-lg font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>
          {title}
        </h2>
        {subtitle && (
          <p className="mt-0.5 text-sm" style={{ color: "var(--text-secondary)" }}>
            {subtitle}
          </p>
        )}
      </div>
      {action}
    </div>
  );
}

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "profit" | "loss" | "neutral" | "gold" | "blue";
  className?: string;
}) {
  const toneVar = {
    profit: "var(--profit)",
    loss: "var(--loss)",
    neutral: "var(--neutral)",
    gold: "var(--gold)",
    blue: "var(--blue)",
  }[tone];
  const toneSoft = {
    profit: "var(--profit-soft)",
    loss: "var(--loss-soft)",
    neutral: "var(--neutral-soft)",
    gold: "var(--gold-soft)",
    blue: "var(--blue-soft)",
  }[tone];

  return (
    <span
      className={clsx("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium", className)}
      style={{ color: toneVar, background: toneSoft }}
    >
      {children}
    </span>
  );
}

export function Button({
  children,
  variant = "primary",
  className,
  ...props
}: {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const base = "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none";
  const styles: Record<string, React.CSSProperties> = {
    primary: { background: "var(--gold)", color: "#15120a" },
    secondary: { background: "var(--card-hover)", color: "var(--text-primary)", border: "1px solid var(--border-strong)" },
    ghost: { background: "transparent", color: "var(--text-secondary)" },
    danger: { background: "var(--loss)", color: "#fff" },
  };
  return (
    <button className={clsx(base, className)} style={styles[variant]} {...props}>
      {children}
    </button>
  );
}

const fieldBase =
  "w-full rounded-xl border px-3.5 py-2.5 text-sm outline-none transition focus:ring-2";

export function Label({ children, required }: { children: ReactNode; required?: boolean }) {
  return (
    <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide" style={{ color: "var(--text-secondary)" }}>
      {children} {required && <span style={{ color: "var(--loss)" }}>*</span>}
    </label>
  );
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={clsx(fieldBase, props.className)}
      style={{
        background: "var(--bg-elevated)",
        borderColor: "var(--border-strong)",
        color: "var(--text-primary)",
      }}
    />
  );
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={clsx(fieldBase, "cursor-pointer", props.className)}
      style={{
        background: "var(--bg-elevated)",
        borderColor: "var(--border-strong)",
        color: "var(--text-primary)",
      }}
    />
  );
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={clsx(fieldBase, "resize-y", props.className)}
      style={{
        background: "var(--bg-elevated)",
        borderColor: "var(--border-strong)",
        color: "var(--text-primary)",
      }}
    />
  );
}

export function StatCard({
  label,
  value,
  tone = "neutral",
  hint,
}: {
  label: string;
  value: string;
  tone?: "profit" | "loss" | "neutral" | "gold" | "blue";
  hint?: string;
}) {
  const toneVar = {
    profit: "var(--profit)",
    loss: "var(--loss)",
    neutral: "var(--text-primary)",
    gold: "var(--gold)",
    blue: "var(--blue)",
  }[tone];
  return (
    <Card className="animate-fade-in">
      <p className="text-xs font-medium uppercase tracking-wide" style={{ color: "var(--text-secondary)" }}>
        {label}
      </p>
      <p className="mt-2 text-2xl font-bold tracking-tight" style={{ color: toneVar }}>
        {value}
      </p>
      {hint && (
        <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
          {hint}
        </p>
      )}
    </Card>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6"
      style={{ background: "rgba(5,8,14,0.65)" }}
      onClick={onClose}
    >
      <div
        className={clsx(
          "max-h-[90vh] w-full overflow-y-auto rounded-2xl border p-5 sm:p-6 animate-fade-in",
          wide ? "max-w-3xl" : "max-w-lg"
        )}
        style={{ background: "var(--bg-elevated)", borderColor: "var(--border-strong)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
            {title}
          </h3>
          <button
            onClick={onClose}
            className="rounded-lg px-2 py-1 text-sm"
            style={{ color: "var(--text-secondary)" }}
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = "Confirm",
  danger,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <Modal open={open} onClose={onCancel} title={title}>
      <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
        {message}
      </p>
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant={danger ? "danger" : "primary"} onClick={onConfirm}>
          {confirmLabel}
        </Button>
      </div>
    </Modal>
  );
}

export function EmptyState({ title, message, action }: { title: string; message: string; action?: ReactNode }) {
  return (
    <div
      className="flex flex-col items-center justify-center rounded-2xl border border-dashed px-6 py-14 text-center animate-fade-in"
      style={{ borderColor: "var(--border-strong)" }}
    >
      <p className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
        {title}
      </p>
      <p className="mt-1.5 max-w-sm text-sm" style={{ color: "var(--text-secondary)" }}>
        {message}
      </p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Spinner() {
  return (
    <div className="flex items-center justify-center py-16">
      <div
        className="h-8 w-8 animate-spin rounded-full border-2 border-t-transparent"
        style={{ borderColor: "var(--gold)", borderTopColor: "transparent" }}
      />
    </div>
  );
}

export function PnlText({ value, currency = "USD" }: { value: number | null; currency?: string }) {
  if (value === null) return <span style={{ color: "var(--text-muted)" }}>—</span>;
  const tone = value > 0 ? "var(--profit)" : value < 0 ? "var(--loss)" : "var(--neutral)";
  const sign = value > 0 ? "+" : "";
  return (
    <span style={{ color: tone }} className="font-semibold">
      {sign}
      {new Intl.NumberFormat("en-US", { style: "currency", currency }).format(value)}
    </span>
  );
}
