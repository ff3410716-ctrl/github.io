import {
  LayoutDashboard,
  PlusCircle,
  History,
  Calendar,
  BarChart3,
  AlertTriangle,
  NotebookPen,
  FileText,
  Settings,
  Menu,
  type LucideProps,
} from "lucide-react";

const ICONS: Record<string, React.ComponentType<LucideProps>> = {
  LayoutDashboard,
  PlusCircle,
  History,
  Calendar,
  BarChart3,
  AlertTriangle,
  NotebookPen,
  FileText,
  Settings,
  Menu,
};

export function Icon({ name, ...props }: { name: string } & LucideProps) {
  const Cmp = ICONS[name] ?? Menu;
  return <Cmp {...props} />;
}
