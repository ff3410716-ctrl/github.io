"use client";

import { useEffect } from "react";

export function ImageLightbox({
  src,
  alt,
  onClose,
}: {
  src: string | null;
  alt?: string;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!src) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [src, onClose]);

  if (!src) return null;
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 p-4"
      onClick={onClose}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt={alt || "Screenshot"} className="max-h-[90vh] max-w-full rounded-xl object-contain shadow-2xl" />
      <button
        onClick={onClose}
        className="absolute right-5 top-5 rounded-full bg-white/10 px-3 py-1.5 text-sm text-white"
      >
        ✕ Close
      </button>
    </div>
  );
}
