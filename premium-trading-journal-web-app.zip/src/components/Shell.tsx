"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Icon } from "./ui/Icon";
import { NAV_ITEMS, MOBILE_NAV_ITEMS } from "@/lib/nav";
import { nowTimestampLabel } from "@/lib/timezone";
import { useAppData } from "@/context/AppDataContext";

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { settings } = useAppData();
  const [clock, setClock] = useState("");

  useEffect(() => {
    const tz = settings?.timeZone || "Asia/Karachi";
    const tick = () => setClock(nowTimestampLabel(tz));
    tick();
    const id = setInterval(tick, 1000 * 30);
    return () => clearInterval(id);
  }, [settings?.timeZone]);

  return (
    <div className="min-h-screen" style={{ background: "var(--bg)" }}>
      <div className="mx-auto flex max-w-[1500px]">
        {/* Desktop sidebar */}
        <aside
          className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r px-4 py-6 md:flex"
          style={{ borderColor: "var(--border)" }}
        >
          <div className="mb-8 flex items-center gap-2 px-2">
            <div
              className="flex h-9 w-9 items-center justify-center rounded-xl text-sm font-bold"
              style={{ background: "var(--gold)", color: "#15120a" }}
            >
              TJ
            </div>
            <div>
              <p className="text-sm font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>
                Trading Journal
              </p>
              <p className="text-[11px]" style={{ color: "var(--text-muted)" }}>
                Premium Edition
              </p>
            </div>
          </div>

          <nav className="flex flex-1 flex-col gap-1">
            {NAV_ITEMS.map((item) => {
              const active = item.href === "/" ? pathname === "/" : pathname?.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition"
                  style={{
                    background: active ? "var(--gold-soft)" : "transparent",
                    color: active ? "var(--gold)" : "var(--text-secondary)",
                  }}
                >
                  <Icon name={item.icon} size={18} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="rounded-xl border px-3 py-3" style={{ borderColor: "var(--border)" }}>
            <p className="text-[11px] uppercase tracking-wide" style={{ color: "var(--text-muted)" }}>
              Local Time ({settings?.timeZone || "Asia/Karachi"})
            </p>
            <p className="mt-1 text-xs font-medium" style={{ color: "var(--text-secondary)" }}>
              {clock || "—"}
            </p>
          </div>
        </aside>

        {/* Main content */}
        <div className="flex min-h-screen flex-1 flex-col">
          <header
            className="sticky top-0 z-30 flex items-center justify-between border-b px-4 py-3 backdrop-blur md:px-8"
            style={{ borderColor: "var(--border)", background: "color-mix(in srgb, var(--bg) 85%, transparent)" }}
          >
            <div className="flex items-center gap-2 md:hidden">
              <div
                className="flex h-8 w-8 items-center justify-center rounded-lg text-xs font-bold"
                style={{ background: "var(--gold)", color: "#15120a" }}
              >
                TJ
              </div>
              <p className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>
                Trading Journal
              </p>
            </div>
            <div className="hidden text-xs md:block" style={{ color: "var(--text-secondary)" }}>
              {clock}
            </div>
            <Link
              href="/trades/new"
              className="ml-auto inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold md:text-sm"
              style={{ background: "var(--gold)", color: "#15120a" }}
            >
              <Icon name="PlusCircle" size={16} />
              Add Trade
            </Link>
          </header>

          <main className="flex-1 px-4 pb-24 pt-5 md:px-8 md:pb-10">{children}</main>
        </div>
      </div>

      {/* Mobile bottom nav */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-around border-t px-1 py-2 md:hidden"
        style={{ borderColor: "var(--border)", background: "var(--bg-elevated)" }}
      >
        {MOBILE_NAV_ITEMS.map((item) => {
          const active = item.href === "/" ? pathname === "/" : pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex flex-col items-center gap-0.5 rounded-lg px-2.5 py-1.5 text-[10px] font-medium"
              style={{ color: active ? "var(--gold)" : "var(--text-muted)" }}
            >
              <Icon name={item.icon} size={20} />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
