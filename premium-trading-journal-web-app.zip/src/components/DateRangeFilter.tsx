"use client";

import { DATE_FILTERS } from "@/lib/constants";
import { DateFilterKey } from "@/lib/analytics";
import { Input } from "./ui/kit";
import clsx from "clsx";

export function DateRangeFilter({
  value,
  onChange,
  custom,
  onCustomChange,
}: {
  value: DateFilterKey;
  onChange: (v: DateFilterKey) => void;
  custom: { from: string; to: string };
  onCustomChange: (v: { from: string; to: string }) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {DATE_FILTERS.map((f) => (
        <button
          key={f}
          onClick={() => onChange(f)}
          className={clsx("rounded-lg px-3 py-1.5 text-xs font-medium transition")}
          style={{
            background: value === f ? "var(--gold)" : "var(--card-hover)",
            color: value === f ? "#15120a" : "var(--text-secondary)",
            border: "1px solid var(--border)",
          }}
        >
          {f}
        </button>
      ))}
      {value === "Custom" && (
        <div className="flex items-center gap-2">
          <Input
            type="date"
            value={custom.from}
            onChange={(e) => onCustomChange({ ...custom, from: e.target.value })}
            className="!w-auto"
          />
          <span style={{ color: "var(--text-muted)" }}>to</span>
          <Input
            type="date"
            value={custom.to}
            onChange={(e) => onCustomChange({ ...custom, to: e.target.value })}
            className="!w-auto"
          />
        </div>
      )}
    </div>
  );
}
