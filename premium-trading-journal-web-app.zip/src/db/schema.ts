import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  timestamp,
  date,
  varchar,
} from "drizzle-orm/pg-core";

// Each trade is a single journal entry with all details captured at once.
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),

  // Timestamps - createdAt is the original creation time and must never be
  // overwritten when editing unrelated fields.
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),

  // Trade date/time (editable for back-dated entries). Stored as plain
  // date + time strings so the user's chosen wall-clock time is preserved
  // regardless of server timezone.
  tradeDate: date("trade_date").notNull(),
  tradeTime: varchar("trade_time", { length: 8 }).notNull(), // HH:mm (24h)

  // Basic info
  instrument: varchar("instrument", { length: 40 }).notNull(),
  customInstrument: varchar("custom_instrument", { length: 60 }),
  market: varchar("market", { length: 20 }).notNull(),

  // Direction
  direction: varchar("direction", { length: 4 }).notNull(), // BUY | SELL

  // Lot size & trade details
  lotSize: numeric("lot_size", { precision: 12, scale: 4 }),
  entryPrice: numeric("entry_price", { precision: 16, scale: 6 }),
  stopLoss: numeric("stop_loss", { precision: 16, scale: 6 }),
  takeProfit: numeric("take_profit", { precision: 16, scale: 6 }),
  exitPrice: numeric("exit_price", { precision: 16, scale: 6 }),
  pips: numeric("pips", { precision: 16, scale: 2 }),
  riskReward: numeric("risk_reward", { precision: 10, scale: 2 }),
  strategy: varchar("strategy", { length: 120 }),
  session: varchar("session", { length: 20 }),

  // Result
  result: varchar("result", { length: 12 }).notNull(), // PROFIT | LOSS | BREAK_EVEN
  pnlUsd: numeric("pnl_usd", { precision: 14, scale: 2 }),
  balanceBefore: numeric("balance_before", { precision: 14, scale: 2 }),
  balanceAfter: numeric("balance_after", { precision: 14, scale: 2 }),
  fees: numeric("fees", { precision: 14, scale: 2 }),

  // Analysis
  entryReason: text("entry_reason"),
  directionReason: text("direction_reason"),
  outcomeReason: text("outcome_reason"),
  followedStrategy: varchar("followed_strategy", { length: 12 }), // Yes/No/Partially
  followedRules: varchar("followed_rules", { length: 12 }),

  // Mistakes & lessons
  mistake: varchar("mistake", { length: 60 }),
  mistakeCustom: varchar("mistake_custom", { length: 160 }),
  whatDifferently: text("what_differently"),
  lessonLearned: text("lesson_learned"),
  nextImprovement: text("next_improvement"),

  // Smart features
  qualityRating: integer("quality_rating"), // 1-10
  emotion: varchar("emotion", { length: 20 }),
  followedPlan: varchar("followed_plan", { length: 12 }), // Yes/No/Partially

  notes: text("notes"),
});

export type TradeRow = typeof trades.$inferSelect;
export type NewTradeRow = typeof trades.$inferInsert;

export const screenshots = pgTable("screenshots", {
  id: serial("id").primaryKey(),
  tradeId: integer("trade_id")
    .notNull()
    .references(() => trades.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  label: varchar("label", { length: 20 }).default("Other").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type ScreenshotRow = typeof screenshots.$inferSelect;
export type NewScreenshotRow = typeof screenshots.$inferInsert;

// Single-row application settings
export const appSettings = pgTable("app_settings", {
  id: integer("id").primaryKey().default(1),
  theme: varchar("theme", { length: 10 }).default("dark").notNull(),
  currency: varchar("currency", { length: 10 }).default("USD").notNull(),
  timeZone: varchar("time_zone", { length: 40 }).default("Asia/Karachi").notNull(),
  dateFormat: varchar("date_format", { length: 30 }).default("dd MMMM yyyy").notNull(),
  defaultInstrument: varchar("default_instrument", { length: 40 }).default("XAUUSD").notNull(),
  weeklyTradeLimit: integer("weekly_trade_limit"),
  dailyMaxLoss: numeric("daily_max_loss", { precision: 14, scale: 2 }),
  monthlyProfitTarget: numeric("monthly_profit_target", { precision: 14, scale: 2 }),
  minQualityScore: integer("min_quality_score"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type AppSettingsRow = typeof appSettings.$inferSelect;

// Mistake improvement status, keyed by mistake name
export const mistakeStatus = pgTable("mistake_status", {
  mistake: varchar("mistake", { length: 60 }).primaryKey(),
  status: varchar("status", { length: 20 }).default("Not Improved").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type MistakeStatusRow = typeof mistakeStatus.$inferSelect;

// Daily review notes (qualitative). Stats are computed from trades.
export const dailyReviews = pgTable("daily_reviews", {
  date: date("date").primaryKey(),
  followedPlan: varchar("followed_plan", { length: 12 }),
  learned: text("learned"),
  improveTomorrow: text("improve_tomorrow"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type DailyReviewRow = typeof dailyReviews.$inferSelect;
